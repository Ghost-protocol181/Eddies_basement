# Codex task for Eddie's Basement

You are working inside a Next.js App Router + TypeScript project called **Eddie's Basement**.

## Product goal

Build a real-feeling web app that helps people find legitimate free multiplayer games. The experience should feel like browsing games on the shelf in an old video rental store, arcade wall, or basement LAN-party collection.

## Do not build

Do not build piracy tooling.
Do not add aggressive unauthorized scraping.
Do not claim this scans the entire internet in real time.
Do not surface fake-free, trial-only, or subscription-required listings in default results.

## Build direction

Improve this starter into a production-ready discovery engine:

1. Keep the visual **Game Shelf** as the default browsing experience.
2. Add Supabase/Postgres persistence.
3. Add real admin authentication.
4. Add source ingestion jobs using legitimate APIs, official feeds, curated sources, and community submissions.
5. Add deduplication and free-status verification.
6. Add a media approval workflow.
7. Add favorites/saved games.
8. Add a better mobile preview drawer.
9. Add real preview video support without loading everything at once.
10. Keep performance high.

## Performance rules

- Lazy-load images.
- Lazy-load video previews.
- Do not autoplay all videos/GIFs.
- Play muted inline video only on active hover/focus/tap.
- Pause previews when inactive.
- Respect prefers-reduced-motion.
- Keep mobile smooth.
- Use approved/cached media in production.

## Free-status rules

Default public results should only show games where:

```ts
isFreeToPlay === true
requiresSubscription === false
freeStatus !== "free_trial_only"
freeStatus !== "subscription_required"
```

## Visual tone

Dark mode first. Cozy basement. Old movie-store shelf. Arcade poster wall. Modern polished app. Warm highlights. Visual game-cover browsing. Fun but trustworthy.

## First coding tasks

1. Run `npm install` and `npm run dev`.
2. Fix any version-specific Next.js/TypeScript issues.
3. Add Supabase schema files or migrations.
4. Replace prototype seed listings with a database-backed `games` table.
5. Add an authenticated admin workflow.
6. Add a real ingestion job scaffold.
7. Add robust media upload/approval fields.
8. Add tests for `isActuallyFree`, filters, search, and questionable listing hiding.

"use client";

import { useState } from "react";
import { Badge } from "@/components/Badge";
import { getAllGames } from "@/lib/games";

export function AdminReviewClient() {
  const [games, setGames] = useState(() => getAllGames({ includeQuestionable: true }).slice(0, 10));

  function updateMediaStatus(slug: string, status: "approved" | "needs_replacement") {
    setGames((current) => current.map((game) => (game.slug === slug ? { ...game, mediaStatus: status } : game)));
  }

  return (
    <div className="admin-card">
      <h2 style={{ marginTop: 0 }}>Review queue mock</h2>
      <p className="muted">
        This is a front-end admin prototype. Wire these actions to Supabase/Postgres when you add real accounts and persistent submissions.
      </p>
      <div className="admin-list">
        {games.map((game) => (
          <div className="admin-item" key={game.id}>
            <img className="admin-thumb" src={game.thumbnailUrl || game.coverImageUrl || "/covers/fallback.svg"} alt="" />
            <div>
              <strong>{game.title}</strong>
              <p className="small" style={{ margin: "6px 0" }}>{game.shortDescription}</p>
              <div className="card-meta">
                <Badge tone={game.mediaStatus === "approved" ? "green" : "orange"}>{game.mediaStatus}</Badge>
                <Badge tone={game.requiresSubscription ? "red" : "green"}>{game.freeStatus}</Badge>
                <Badge tone="blue">Trust {game.trustScore}</Badge>
              </div>
            </div>
            <div style={{ display: "grid", gap: 8 }}>
              <button className="button primary" type="button" onClick={() => updateMediaStatus(game.slug, "approved")}>Approve media</button>
              <button className="button ghost" type="button" onClick={() => updateMediaStatus(game.slug, "needs_replacement")}>Needs replacement</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

"use client";

import Link from "next/link";
import { useState } from "react";
import { Badge } from "@/components/Badge";
import { MediaBadge } from "@/components/MediaBadge";
import { MediaPreviewCard } from "@/components/MediaPreviewCard";
import { TrustBadge } from "@/components/TrustBadge";
import { getPrimaryArtwork } from "@/lib/media";
import type { Game, ViewMode } from "@/lib/types";

type GameCoverCardProps = {
  game: Game;
  viewMode?: ViewMode;
};

export function GameCoverCard({ game, viewMode = "shelf" }: GameCoverCardProps) {
  const [active, setActive] = useState(false);
  const playerCount = game.playerCountMin === game.playerCountMax ? `${game.playerCountMin}` : `${game.playerCountMin}-${game.playerCountMax}`;
  const artwork = getPrimaryArtwork(game);
  const compact = viewMode === "list";

  return (
    <article
      className={`game-card ${compact ? "compact" : ""} ${active ? "is-active" : ""}`}
      onMouseEnter={() => setActive(true)}
      onMouseLeave={() => setActive(false)}
    >
      <div className="media-frame">
        <img className="cover-img" src={artwork} alt={`${game.title} cover art`} loading="lazy" />
        <MediaPreviewCard game={game} active={active} />
        <div className="card-badges">
          <TrustBadge game={game} />
          {game.eddiesPick ? <Badge tone="purple">Eddie&apos;s Pick</Badge> : null}
        </div>
        <button
          type="button"
          aria-label={`Preview ${game.title}`}
          onClick={() => setActive((current) => !current)}
          onFocus={() => setActive(true)}
          onBlur={() => setActive(false)}
        />
        <div className="media-gradient" />
      </div>

      <div className="card-body">
        <h3 className="card-title">{game.title}</h3>
        <p className="card-desc">{game.shortDescription}</p>
        <div className="card-meta">
          <Badge tone="blue">{playerCount} players</Badge>
          {game.browserPlayable ? <Badge tone="green">Browser</Badge> : null}
          {!game.downloadRequired ? <Badge tone="green">No download</Badge> : null}
          {game.multiplayerTypes.slice(0, 2).map((type) => (
            <Badge key={type} tone="blue">{type}</Badge>
          ))}
          <MediaBadge game={game} />
        </div>
        <div className="card-actions">
          <a className="button primary" href={game.officialUrl} target="_blank" rel="noreferrer">
            Play / Visit
          </a>
          <Link className="button ghost" href={`/games/${game.slug}`}>
            Details
          </Link>
        </div>
      </div>
    </article>
  );
}

import { GameCoverCard } from "@/components/GameCoverCard";
import type { Game, ViewMode } from "@/lib/types";

export function GameGrid({ games, viewMode }: { games: Game[]; viewMode: ViewMode }) {
  if (!games.length) {
    return (
      <div className="empty-state">
        <h2>No games found.</h2>
        <p className="muted">Try removing a filter or searching for another genre, platform, or multiplayer type.</p>
      </div>
    );
  }

  return (
    <div className={`grid ${viewMode === "list" ? "list-view" : viewMode === "grid" ? "grid-view" : "shelf"}`}>
      {games.map((game) => (
        <GameCoverCard key={game.id} game={game} viewMode={viewMode} />
      ))}
    </div>
  );
}

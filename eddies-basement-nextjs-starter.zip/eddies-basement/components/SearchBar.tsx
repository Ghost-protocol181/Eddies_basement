"use client";

export function SearchBar({ value, onChange }: { value: string; onChange: (value: string) => void }) {
  return (
    <input
      className="search-input"
      type="search"
      value={value}
      onChange={(event) => onChange(event.target.value)}
      placeholder="Find a free multiplayer game..."
      aria-label="Search games"
    />
  );
}

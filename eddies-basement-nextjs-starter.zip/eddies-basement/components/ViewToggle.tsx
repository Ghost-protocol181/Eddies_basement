"use client";

import type { ViewMode } from "@/lib/types";

const views: ViewMode[] = ["shelf", "grid", "list"];

export function ViewToggle({ value, onChange }: { value: ViewMode; onChange: (value: ViewMode) => void }) {
  return (
    <div className="view-toggle" aria-label="View mode">
      {views.map((view) => (
        <button key={view} type="button" className={value === view ? "active" : ""} onClick={() => onChange(view)}>
          {view[0].toUpperCase() + view.slice(1)}
        </button>
      ))}
    </div>
  );
}

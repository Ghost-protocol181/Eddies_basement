import Link from "next/link";
import { GameCoverCard } from "@/components/GameCoverCard";
import type { Game } from "@/lib/types";

type GameShelfRowProps = {
  title: string;
  description: string;
  games: Game[];
  href?: string;
};

export function GameShelfRow({ title, description, games, href = "/games" }: GameShelfRowProps) {
  if (!games.length) return null;

  return (
    <section className="section">
      <div className="section-header">
        <div>
          <h2>{title}</h2>
          <p>{description}</p>
        </div>
        <Link href={href} className="button ghost">Browse all</Link>
      </div>
      <div className="shelf-wrap">
        <div className="shelf-row" aria-label={title}>
          {games.map((game) => (
            <GameCoverCard key={game.id} game={game} />
          ))}
        </div>
      </div>
    </section>
  );
}

import Link from "next/link";

export function SiteShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="site-shell">
      <header className="site-header">
        <div className="site-header-inner">
          <Link href="/" className="logo" aria-label="Eddie's Basement home">
            <span className="logo-mark">EB</span>
            <span>
              <span className="logo-title">Eddie&apos;s Basement</span>
              <span className="logo-subtitle">Free multiplayer game shelf</span>
            </span>
          </Link>
          <nav className="nav" aria-label="Main navigation">
            <Link href="/games">Game Shelf</Link>
            <Link href="/submit">Submit a Game</Link>
            <Link href="/admin">Admin Mock</Link>
          </nav>
        </div>
      </header>
      <main className="page">{children}</main>
      <footer className="site-footer">
        <div className="site-footer-inner">
          <strong>Eddie&apos;s Basement links to official game pages and legitimate sources only.</strong>
          <span>
            Listings should be reviewed for free access, multiplayer support, media rights, and monetization transparency before public launch.
          </span>
        </div>
      </footer>
    </div>
  );
}

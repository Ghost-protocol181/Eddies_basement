"use client";

import { useMemo, useState } from "react";
import { FilterBar } from "@/components/FilterBar";
import { GameGrid } from "@/components/GameGrid";
import { SearchBar } from "@/components/SearchBar";
import { ViewToggle } from "@/components/ViewToggle";
import { defaultFilters, filterGames, searchGames, sortGames } from "@/lib/filters";
import type { FilterState, Game, ViewMode } from "@/lib/types";

export function DirectoryClient({ games }: { games: Game[] }) {
  const [query, setQuery] = useState("");
  const [viewMode, setViewMode] = useState<ViewMode>("shelf");
  const [filters, setFilters] = useState<FilterState>(defaultFilters);
  const [showQuestionable, setShowQuestionable] = useState(false);
  const [sortKey, setSortKey] = useState("best");

  const visibleGames = useMemo(() => {
    return sortGames(filterGames(searchGames(games, query), filters, showQuestionable), sortKey);
  }, [games, query, filters, showQuestionable, sortKey]);

  return (
    <>
      <div className="directory-tools">
        <SearchBar value={query} onChange={setQuery} />
        <div style={{ display: "flex", gap: 10, flexWrap: "wrap", justifyContent: "flex-end" }}>
          <select className="search-input" style={{ width: "auto" }} value={sortKey} onChange={(event) => setSortKey(event.target.value)} aria-label="Sort games">
            <option value="best">Best match</option>
            <option value="most-verified">Most verified</option>
            <option value="least-monetized">Least monetized</option>
            <option value="group-friendly">Best for groups</option>
            <option value="newest">Newest</option>
          </select>
          <ViewToggle value={viewMode} onChange={setViewMode} />
        </div>
      </div>

      <FilterBar
        games={games}
        filters={filters}
        onChange={setFilters}
        showQuestionable={showQuestionable}
        onShowQuestionableChange={setShowQuestionable}
      />

      <p className="small" style={{ marginBottom: 18 }}>
        Showing {visibleGames.length} listing{visibleGames.length === 1 ? "" : "s"}. Default results hide trial-only, subscription-required, and questionable listings.
      </p>

      <GameGrid games={visibleGames} viewMode={viewMode} />
    </>
  );
}

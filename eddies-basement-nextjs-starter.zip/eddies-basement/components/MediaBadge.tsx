import { Badge } from "@/components/Badge";
import { mediaLabel } from "@/lib/media";
import type { Game } from "@/lib/types";

export function MediaBadge({ game }: { game: Game }) {
  const tone = game.mediaStatus === "approved" ? "purple" : game.mediaStatus === "needs_replacement" ? "orange" : "blue";
  return <Badge tone={tone}>{mediaLabel(game)}</Badge>;
}

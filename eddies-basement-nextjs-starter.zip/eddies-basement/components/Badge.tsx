export function Badge({ children, tone = "blue" }: { children: React.ReactNode; tone?: "green" | "yellow" | "orange" | "red" | "blue" | "purple" }) {
  return <span className={`badge ${tone}`}>{children}</span>;
}

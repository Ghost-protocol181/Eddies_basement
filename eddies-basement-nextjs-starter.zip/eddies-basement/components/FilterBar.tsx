"use client";

import type { FilterState, Game } from "@/lib/types";
import { uniqueValues } from "@/lib/filters";

const booleanFilters: Array<{ key: keyof Pick<FilterState, "browserOnly" | "noDownload" | "noAccount" | "lowMonetization" | "familyBrowse">; label: string }> = [
  { key: "browserOnly", label: "Browser playable" },
  { key: "noDownload", label: "No download" },
  { key: "noAccount", label: "No account" },
  { key: "lowMonetization", label: "Low monetization" },
  { key: "familyBrowse", label: "Family Browse" }
];

export function FilterBar({ games, filters, onChange, showQuestionable, onShowQuestionableChange }: {
  games: Game[];
  filters: FilterState;
  onChange: (filters: FilterState) => void;
  showQuestionable: boolean;
  onShowQuestionableChange: (value: boolean) => void;
}) {
  const platforms = uniqueValues(games, "platforms");
  const genres = uniqueValues(games, "genres");
  const multiplayerTypes = uniqueValues(games, "multiplayerTypes");

  return (
    <aside className="filter-panel" aria-label="Game filters">
      <div className="filter-label">Quick filters</div>
      <div className="filter-group">
        {booleanFilters.map((filter) => (
          <button
            key={filter.key}
            type="button"
            className={`chip ${filters[filter.key] ? "active" : ""}`}
            onClick={() => onChange({ ...filters, [filter.key]: !filters[filter.key] })}
          >
            {filter.label}
          </button>
        ))}
        <button
          type="button"
          className={`chip ${showQuestionable ? "active" : ""}`}
          onClick={() => onShowQuestionableChange(!showQuestionable)}
        >
          Show questionable
        </button>
      </div>

      <div className="filter-label">Platform</div>
      <div className="filter-group">
        {platforms.map((platform) => (
          <button key={platform} type="button" className={`chip ${filters.platform === platform ? "active" : ""}`} onClick={() => onChange({ ...filters, platform })}>
            {platform}
          </button>
        ))}
      </div>

      <div className="filter-label">Multiplayer type</div>
      <div className="filter-group">
        {multiplayerTypes.map((type) => (
          <button key={type} type="button" className={`chip ${filters.multiplayerType === type ? "active" : ""}`} onClick={() => onChange({ ...filters, multiplayerType: type })}>
            {type}
          </button>
        ))}
      </div>

      <div className="filter-label">Genre</div>
      <div className="filter-group">
        {genres.map((genre) => (
          <button key={genre} type="button" className={`chip ${filters.genre === genre ? "active" : ""}`} onClick={() => onChange({ ...filters, genre })}>
            {genre}
          </button>
        ))}
      </div>
    </aside>
  );
}

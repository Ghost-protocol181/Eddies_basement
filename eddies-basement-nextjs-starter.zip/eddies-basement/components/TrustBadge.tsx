import { Badge } from "@/components/Badge";
import type { Game } from "@/lib/types";

export function TrustBadge({ game }: { game: Game }) {
  if (game.freeStatus === "verified_free" && game.monetizationLevel === "none") {
    return <Badge tone="green">Verified free</Badge>;
  }

  if (game.freeStatus === "free_with_iap") {
    return <Badge tone="yellow">Free + optional purchases</Badge>;
  }

  if (game.freeStatus === "free_trial_only") {
    return <Badge tone="red">Trial only</Badge>;
  }

  if (game.requiresSubscription) {
    return <Badge tone="red">Subscription required</Badge>;
  }

  return <Badge tone="orange">Needs verification</Badge>;
}

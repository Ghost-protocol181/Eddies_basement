"use client";

import { useInView } from "@/hooks/useInView";
import { usePrefersReducedMotion } from "@/hooks/usePrefersReducedMotion";
import { PreviewVideo } from "@/components/PreviewVideo";
import type { Game } from "@/lib/types";

type MediaPreviewCardProps = {
  game: Game;
  active: boolean;
};

export function MediaPreviewCard({ game, active }: MediaPreviewCardProps) {
  const { ref, inView } = useInView<HTMLDivElement>();
  const reducedMotion = usePrefersReducedMotion();
  const shouldShowAnimatedImage = Boolean(active && inView && !reducedMotion && !game.previewVideoUrl && game.previewGifUrl);

  if (game.previewVideoUrl) {
    return <PreviewVideo src={game.previewVideoUrl} poster={game.previewVideoPosterUrl || game.coverImageUrl} active={active} />;
  }

  return (
    <div ref={ref} className="preview-layer" aria-hidden="true">
      {shouldShowAnimatedImage ? (
        <img className="preview-img" src={game.previewGifUrl} alt="" loading="lazy" />
      ) : game.screenshotUrls?.[0] ? (
        <img className="preview-img" src={game.screenshotUrls[0]} alt="" loading="lazy" />
      ) : null}
    </div>
  );
}

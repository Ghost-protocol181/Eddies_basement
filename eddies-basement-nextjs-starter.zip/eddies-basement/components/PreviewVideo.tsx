"use client";

import { useEffect, useRef } from "react";
import { useInView } from "@/hooks/useInView";
import { usePrefersReducedMotion } from "@/hooks/usePrefersReducedMotion";

type PreviewVideoProps = {
  src?: string;
  poster?: string;
  active: boolean;
};

export function PreviewVideo({ src, poster, active }: PreviewVideoProps) {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const { ref, inView } = useInView<HTMLDivElement>();
  const reducedMotion = usePrefersReducedMotion();
  const shouldLoad = Boolean(src && inView && !reducedMotion);
  const shouldPlay = shouldLoad && active;

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    if (shouldPlay) {
      video.play().catch(() => {
        // Browser autoplay rules may block playback. The static poster still works.
      });
    } else {
      video.pause();
      video.currentTime = 0;
    }
  }, [shouldPlay]);

  return (
    <div ref={ref} className="preview-layer" aria-hidden="true">
      {shouldLoad ? (
        <video
          ref={videoRef}
          className="preview-video"
          poster={poster}
          muted
          loop
          playsInline
          preload="none"
        >
          <source src={src} type="video/mp4" />
        </video>
      ) : poster ? (
        <img className="preview-img" src={poster} alt="" loading="lazy" />
      ) : null}
    </div>
  );
}

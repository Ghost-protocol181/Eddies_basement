export function ScreenshotCarousel({ urls, title }: { urls?: string[]; title: string }) {
  if (!urls?.length) return null;

  return (
    <div className="gallery" aria-label={`${title} screenshots`}>
      {urls.map((url, index) => (
        <img key={url} src={url} alt={`${title} screenshot ${index + 1}`} loading="lazy" />
      ))}
    </div>
  );
}

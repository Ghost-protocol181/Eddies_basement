"use client";

import { useState } from "react";
import type { Submission } from "@/lib/types";

const initial: Submission = {
  gameName: "",
  officialUrl: "",
  platform: "Browser",
  multiplayerType: "Online",
  trulyFree: "yes",
  requiresSubscription: "no",
  notes: ""
};

export function SubmitGameForm() {
  const [form, setForm] = useState(initial);
  const [status, setStatus] = useState<string | null>(null);

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setStatus("Submitting...");

    const response = await fetch("/api/submissions", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form)
    });

    if (!response.ok) {
      setStatus("Something went wrong. Please check the required fields.");
      return;
    }

    setForm(initial);
    setStatus("Submitted for review. In production this would create a pending admin item.");
  }

  function update<K extends keyof Submission>(key: K, value: Submission[K]) {
    setForm((current) => ({ ...current, [key]: value }));
  }

  return (
    <form className="form-card form-grid" onSubmit={submit}>
      <div className="form-row">
        <label htmlFor="gameName">Game name</label>
        <input id="gameName" value={form.gameName} onChange={(event) => update("gameName", event.target.value)} required />
      </div>
      <div className="form-row">
        <label htmlFor="officialUrl">Official URL</label>
        <input id="officialUrl" type="url" value={form.officialUrl} onChange={(event) => update("officialUrl", event.target.value)} required />
      </div>
      <div className="form-row">
        <label htmlFor="platform">Primary platform</label>
        <select id="platform" value={form.platform} onChange={(event) => update("platform", event.target.value)}>
          <option>Browser</option>
          <option>Windows</option>
          <option>macOS</option>
          <option>Mobile</option>
          <option>Console</option>
        </select>
      </div>
      <div className="form-row">
        <label htmlFor="multiplayerType">Multiplayer type</label>
        <select id="multiplayerType" value={form.multiplayerType} onChange={(event) => update("multiplayerType", event.target.value)}>
          <option>Online</option>
          <option>Local</option>
          <option>Co-op</option>
          <option>Competitive</option>
          <option>Party</option>
          <option>MMO</option>
        </select>
      </div>
      <div className="form-row">
        <label htmlFor="trulyFree">Is it truly free to start?</label>
        <select id="trulyFree" value={form.trulyFree} onChange={(event) => update("trulyFree", event.target.value)}>
          <option value="yes">Yes</option>
          <option value="not sure">Not sure</option>
          <option value="no">No</option>
        </select>
      </div>
      <div className="form-row">
        <label htmlFor="requiresSubscription">Does it require a subscription?</label>
        <select id="requiresSubscription" value={form.requiresSubscription} onChange={(event) => update("requiresSubscription", event.target.value)}>
          <option value="no">No</option>
          <option value="not sure">Not sure</option>
          <option value="yes">Yes</option>
        </select>
      </div>
      <div className="form-row">
        <label htmlFor="notes">Notes</label>
        <textarea id="notes" value={form.notes} onChange={(event) => update("notes", event.target.value)} placeholder="Monetization, player count, why it belongs, etc." />
      </div>
      <button className="button primary" type="submit">Submit for review</button>
      {status ? <p className="small">{status}</p> : null}
    </form>
  );
}

import type { SourceAdapter, RawGame } from "@/lib/sources/types";
import type { Game } from "@/lib/types";

export const curatedJsonSource: SourceAdapter = {
  name: "Curated JSON",
  async fetchGames() {
    // In production, fetch from a private reviewed JSON source or CMS endpoint.
    return [];
  },
  normalize(raw: RawGame): Game {
    const now = new Date().toISOString();

    return {
      id: String(raw.id ?? crypto.randomUUID()),
      title: String(raw.title ?? "Untitled game"),
      slug: String(raw.slug ?? "untitled-game"),
      description: String(raw.description ?? ""),
      shortDescription: String(raw.shortDescription ?? ""),
      officialUrl: String(raw.officialUrl ?? ""),
      mediaStatus: "pending_review",
      platforms: Array.isArray(raw.platforms) ? raw.platforms.map(String) : [],
      genres: Array.isArray(raw.genres) ? raw.genres.map(String) : [],
      multiplayerTypes: Array.isArray(raw.multiplayerTypes) ? raw.multiplayerTypes.map(String) : [],
      playerCountMin: Number(raw.playerCountMin ?? 2),
      playerCountMax: Number(raw.playerCountMax ?? 4),
      isFreeToPlay: Boolean(raw.isFreeToPlay),
      requiresSubscription: Boolean(raw.requiresSubscription),
      hasInAppPurchases: Boolean(raw.hasInAppPurchases),
      hasPaidDLC: Boolean(raw.hasPaidDLC),
      downloadRequired: Boolean(raw.downloadRequired),
      accountRequired: Boolean(raw.accountRequired),
      browserPlayable: Boolean(raw.browserPlayable),
      controllerFriendly: Boolean(raw.controllerFriendly),
      crossPlatform: Boolean(raw.crossPlatform),
      monetizationLevel: "unknown",
      freeStatus: "unknown",
      trustScore: 40,
      sourceName: "Curated JSON",
      sourceUrl: "private-curated-json",
      lastCheckedAt: now,
      createdAt: now,
      updatedAt: now,
      tags: []
    };
  }
};

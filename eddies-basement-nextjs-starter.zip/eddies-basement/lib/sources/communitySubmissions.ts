import type { SourceAdapter, RawGame } from "@/lib/sources/types";
import type { Game } from "@/lib/types";

export const communitySubmissionsSource: SourceAdapter = {
  name: "Community submissions",
  async fetchGames() {
    // Production: fetch pending/approved submissions from your database.
    return [];
  },
  normalize(raw: RawGame): Game {
    const title = String(raw.gameName ?? raw.title ?? "Community submission");
    const slug = title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
    const now = new Date().toISOString();

    return {
      id: crypto.randomUUID(),
      title,
      slug,
      description: String(raw.notes ?? "Community-submitted listing pending review."),
      shortDescription: "Community-submitted listing pending review.",
      officialUrl: String(raw.officialUrl ?? ""),
      mediaStatus: "pending_review",
      platforms: [String(raw.platform ?? "Unknown")],
      genres: [],
      multiplayerTypes: [String(raw.multiplayerType ?? "Online")],
      playerCountMin: 2,
      playerCountMax: 4,
      isFreeToPlay: raw.trulyFree === "yes",
      requiresSubscription: raw.requiresSubscription === "yes",
      hasInAppPurchases: false,
      hasPaidDLC: false,
      downloadRequired: false,
      accountRequired: false,
      browserPlayable: String(raw.platform ?? "").toLowerCase() === "browser",
      controllerFriendly: false,
      crossPlatform: false,
      monetizationLevel: "unknown",
      freeStatus: "unknown",
      trustScore: 25,
      sourceName: "Community submission",
      sourceUrl: "database://community-submissions",
      lastCheckedAt: now,
      createdAt: now,
      updatedAt: now,
      tags: ["pending-review"]
    };
  }
};

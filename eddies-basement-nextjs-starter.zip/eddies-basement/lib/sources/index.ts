import { communitySubmissionsSource } from "@/lib/sources/communitySubmissions";
import { curatedJsonSource } from "@/lib/sources/curatedJson";
import { publicApiPlaceholderSource } from "@/lib/sources/publicApiPlaceholder";
import type { SourceAdapter } from "@/lib/sources/types";

export const sourceAdapters: SourceAdapter[] = [
  curatedJsonSource,
  communitySubmissionsSource,
  publicApiPlaceholderSource
];

export async function ingestFromSources() {
  const games = [];

  for (const source of sourceAdapters) {
    const rawGames = await source.fetchGames();
    games.push(...rawGames.map((raw) => source.normalize(raw)));
  }

  return games;
}

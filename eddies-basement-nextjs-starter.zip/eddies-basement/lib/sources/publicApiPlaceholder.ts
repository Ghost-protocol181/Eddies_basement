import type { SourceAdapter, RawGame } from "@/lib/sources/types";
import type { Game } from "@/lib/types";

export const publicApiPlaceholderSource: SourceAdapter = {
  name: "Public API placeholder",
  async fetchGames() {
    // Add adapters for legitimate public APIs only.
    // Respect API terms, robots.txt, rate limits, media rights, and copyright.
    // Avoid aggressive scraping. Prefer official game/store APIs, approved feeds, or curated lists.
    return [];
  },
  normalize(_raw: RawGame): Game {
    throw new Error("Implement normalize() for each real source because every source schema is different.");
  }
};

import type { Game } from "@/lib/types";

export type RawGame = Record<string, unknown>;

export type SourceAdapter = {
  name: string;
  fetchGames(): Promise<RawGame[]>;
  normalize(raw: RawGame): Game;
};

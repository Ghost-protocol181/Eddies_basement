import type { FilterState, Game } from "@/lib/types";

export const defaultFilters: FilterState = {
  browserOnly: false,
  noDownload: false,
  noAccount: false,
  lowMonetization: false,
  familyBrowse: false,
  platform: "All",
  multiplayerType: "All",
  genre: "All"
};

export function isActuallyFree(game: Game): boolean {
  return (
    game.isFreeToPlay === true &&
    game.requiresSubscription === false &&
    game.freeStatus !== "free_trial_only" &&
    game.freeStatus !== "subscription_required"
  );
}

export function isLowMonetization(game: Game): boolean {
  return game.monetizationLevel === "none" || game.monetizationLevel === "light";
}

export function searchGames(games: Game[], query: string): Game[] {
  const cleanQuery = query.trim().toLowerCase();
  if (!cleanQuery) return games;

  return games.filter((game) => {
    const searchable = [
      game.title,
      game.description,
      game.shortDescription,
      ...game.platforms,
      ...game.genres,
      ...game.multiplayerTypes,
      ...game.tags
    ]
      .join(" ")
      .toLowerCase();

    return searchable.includes(cleanQuery);
  });
}

export function filterGames(games: Game[], filters: FilterState, showQuestionable = false): Game[] {
  return games.filter((game) => {
    if (!showQuestionable && !isActuallyFree(game)) return false;
    if (filters.browserOnly && !game.browserPlayable) return false;
    if (filters.noDownload && game.downloadRequired) return false;
    if (filters.noAccount && game.accountRequired) return false;
    if (filters.lowMonetization && !isLowMonetization(game)) return false;
    if (filters.familyBrowse && !game.familyBrowseRecommended) return false;
    if (filters.platform !== "All" && !game.platforms.includes(filters.platform)) return false;
    if (filters.multiplayerType !== "All" && !game.multiplayerTypes.includes(filters.multiplayerType)) return false;
    if (filters.genre !== "All" && !game.genres.includes(filters.genre)) return false;
    return true;
  });
}

export function uniqueValues(games: Game[], field: "platforms" | "genres" | "multiplayerTypes"): string[] {
  return ["All", ...Array.from(new Set(games.flatMap((game) => game[field]))).sort()];
}

export function sortGames(games: Game[], sortKey: string): Game[] {
  const copy = [...games];

  switch (sortKey) {
    case "newest":
      return copy.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    case "least-monetized":
      return copy.sort((a, b) => monetizationRank(a.monetizationLevel) - monetizationRank(b.monetizationLevel));
    case "most-verified":
      return copy.sort((a, b) => b.trustScore - a.trustScore);
    case "group-friendly":
      return copy.sort((a, b) => b.playerCountMax - a.playerCountMax);
    default:
      return copy.sort((a, b) => Number(Boolean(b.eddiesPick)) - Number(Boolean(a.eddiesPick)) || b.trustScore - a.trustScore);
  }
}

function monetizationRank(level: Game["monetizationLevel"]): number {
  const ranks = { none: 0, light: 1, moderate: 2, heavy: 3, unknown: 4 };
  return ranks[level];
}

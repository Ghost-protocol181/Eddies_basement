export type MonetizationLevel = "none" | "light" | "moderate" | "heavy" | "unknown";
export type FreeStatus = "verified_free" | "free_with_iap" | "free_trial_only" | "subscription_required" | "unknown";
export type MediaStatus = "missing" | "pending_review" | "approved" | "needs_replacement";

export type Game = {
  id: string;
  title: string;
  slug: string;
  description: string;
  shortDescription: string;
  officialUrl: string;
  coverImageUrl?: string;
  heroImageUrl?: string;
  thumbnailUrl?: string;
  previewGifUrl?: string;
  previewVideoUrl?: string;
  previewVideoPosterUrl?: string;
  screenshotUrls?: string[];
  mediaAttribution?: string;
  mediaSourceUrl?: string;
  mediaStatus: MediaStatus;
  platforms: string[];
  genres: string[];
  multiplayerTypes: string[];
  playerCountMin: number;
  playerCountMax: number;
  isFreeToPlay: boolean;
  requiresSubscription: boolean;
  hasInAppPurchases: boolean;
  hasPaidDLC: boolean;
  downloadRequired: boolean;
  accountRequired: boolean;
  browserPlayable: boolean;
  controllerFriendly: boolean;
  crossPlatform: boolean;
  monetizationLevel: MonetizationLevel;
  freeStatus: FreeStatus;
  trustScore: number;
  sourceName: string;
  sourceUrl: string;
  lastCheckedAt: string;
  createdAt: string;
  updatedAt: string;
  tags: string[];
  featuredShelf?: boolean;
  eddiesPick?: boolean;
  familyBrowseRecommended?: boolean;
};

export type ViewMode = "shelf" | "grid" | "list";

export type FilterState = {
  browserOnly: boolean;
  noDownload: boolean;
  noAccount: boolean;
  lowMonetization: boolean;
  familyBrowse: boolean;
  platform: string;
  multiplayerType: string;
  genre: string;
};

export type Submission = {
  gameName: string;
  officialUrl: string;
  platform: string;
  multiplayerType: string;
  trulyFree: string;
  requiresSubscription: string;
  notes: string;
};

import type { Game } from "@/lib/types";

export function getPrimaryArtwork(game: Game): string {
  return game.coverImageUrl || game.thumbnailUrl || "/covers/fallback.svg";
}

export function getHeroArtwork(game: Game): string {
  return game.heroImageUrl || getPrimaryArtwork(game);
}

export function hasApprovedMedia(game: Game): boolean {
  return game.mediaStatus === "approved" && Boolean(game.coverImageUrl || game.thumbnailUrl);
}

export function mediaLabel(game: Game): string {
  switch (game.mediaStatus) {
    case "approved":
      return "Media approved";
    case "pending_review":
      return "Media pending";
    case "needs_replacement":
      return "Needs media";
    default:
      return "Placeholder";
  }
}

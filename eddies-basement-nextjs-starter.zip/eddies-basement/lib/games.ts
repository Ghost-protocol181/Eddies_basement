import { seedGames } from "@/lib/seed";
import { isActuallyFree } from "@/lib/filters";
import type { Game } from "@/lib/types";

export function getAllGames(options?: { includeQuestionable?: boolean }): Game[] {
  if (options?.includeQuestionable) return seedGames;
  return seedGames.filter(isActuallyFree);
}

export function getFeaturedGames(): Game[] {
  return getAllGames().filter((game) => game.featuredShelf).slice(0, 12);
}

export function getPlayNowGames(): Game[] {
  return getAllGames()
    .filter((game) => game.browserPlayable && !game.downloadRequired)
    .sort((a, b) => b.trustScore - a.trustScore)
    .slice(0, 12);
}

export function getFamilyGames(): Game[] {
  return getAllGames()
    .filter((game) => game.familyBrowseRecommended)
    .slice(0, 12);
}

export function getGameBySlug(slug: string): Game | undefined {
  return seedGames.find((game) => game.slug === slug);
}

export function getSimilarGames(game: Game): Game[] {
  const tags = new Set([...game.genres, ...game.multiplayerTypes, ...game.platforms]);

  return getAllGames()
    .filter((candidate) => candidate.slug !== game.slug)
    .map((candidate) => ({
      game: candidate,
      score: [...candidate.genres, ...candidate.multiplayerTypes, ...candidate.platforms].filter((item) => tags.has(item)).length
    }))
    .filter((item) => item.score > 0)
    .sort((a, b) => b.score - a.score || b.game.trustScore - a.game.trustScore)
    .slice(0, 8)
    .map((item) => item.game);
}

import type { Game } from "@/lib/types";

export const seedGames: Game[] = [
  {
    "id": "game-001",
    "title": "Neon Knockout",
    "slug": "neon-knockout",
    "description": "Fast browser arena rounds for 2\u20138 players with short match times. This starter listing is sample data for the Eddie's Basement prototype. Replace it with verified official listings before public launch.",
    "shortDescription": "Fast browser arena rounds for 2\u20138 players with short match times.",
    "officialUrl": "https://example.com/games/neon-knockout",
    "coverImageUrl": "/covers/neon-knockout.svg",
    "heroImageUrl": "/covers/neon-knockout-hero.svg",
    "thumbnailUrl": "/covers/neon-knockout.svg",
    "previewGifUrl": "/previews/neon-knockout-preview.svg",
    "previewVideoPosterUrl": "/covers/neon-knockout.svg",
    "screenshotUrls": [
      "/screens/neon-knockout-screen-1.svg",
      "/screens/neon-knockout-screen-2.svg"
    ],
    "mediaAttribution": "Prototype placeholder artwork generated for Eddie's Basement.",
    "mediaSourceUrl": "local-prototype-assets",
    "mediaStatus": "approved",
    "platforms": [
      "Browser"
    ],
    "genres": [
      "Arena",
      "Action"
    ],
    "multiplayerTypes": [
      "Online",
      "Competitive"
    ],
    "playerCountMin": 2,
    "playerCountMax": 8,
    "isFreeToPlay": true,
    "requiresSubscription": false,
    "hasInAppPurchases": false,
    "hasPaidDLC": false,
    "downloadRequired": false,
    "accountRequired": false,
    "browserPlayable": true,
    "controllerFriendly": false,
    "crossPlatform": false,
    "monetizationLevel": "none",
    "freeStatus": "verified_free",
    "trustScore": 92,
    "sourceName": "Prototype seed data",
    "sourceUrl": "local://seed",
    "lastCheckedAt": "2026-07-10T00:00:00.000Z",
    "createdAt": "2026-07-10T00:00:00.000Z",
    "updatedAt": "2026-07-10T00:00:00.000Z",
    "tags": [
      "no-download",
      "quick-match"
    ],
    "featuredShelf": true,
    "eddiesPick": true,
    "familyBrowseRecommended": true
  },
  {
    "id": "game-002",
    "title": "Couch Castle",
    "slug": "couch-castle",
    "description": "A friendly local co-op defense game built for a shared screen. This starter listing is sample data for the Eddie's Basement prototype. Replace it with verified official listings before public launch.",
    "shortDescription": "A friendly local co-op defense game built for a shared screen.",
    "officialUrl": "https://example.com/games/couch-castle",
    "coverImageUrl": "/covers/couch-castle.svg",
    "heroImageUrl": "/covers/couch-castle-hero.svg",
    "thumbnailUrl": "/covers/couch-castle.svg",
    "previewGifUrl": "/previews/couch-castle-preview.svg",
    "previewVideoPosterUrl": "/covers/couch-castle.svg",
    "screenshotUrls": [
      "/screens/couch-castle-screen-1.svg",
      "/screens/couch-castle-screen-2.svg"
    ],
    "mediaAttribution": "Prototype placeholder artwork generated for Eddie's Basement.",
    "mediaSourceUrl": "local-prototype-assets",
    "mediaStatus": "approved",
    "platforms": [
      "Browser",
      "Windows"
    ],
    "genres": [
      "Co-op",
      "Defense"
    ],
    "multiplayerTypes": [
      "Local",
      "Co-op"
    ],
    "playerCountMin": 2,
    "playerCountMax": 4,
    "isFreeToPlay": true,
    "requiresSubscription": false,
    "hasInAppPurchases": false,
    "hasPaidDLC": false,
    "downloadRequired": false,
    "accountRequired": true,
    "browserPlayable": true,
    "controllerFriendly": true,
    "crossPlatform": true,
    "monetizationLevel": "light",
    "freeStatus": "free_with_iap",
    "trustScore": 78,
    "sourceName": "Prototype seed data",
    "sourceUrl": "local://seed",
    "lastCheckedAt": "2026-07-10T00:00:00.000Z",
    "createdAt": "2026-07-10T00:00:00.000Z",
    "updatedAt": "2026-07-10T00:00:00.000Z",
    "tags": [
      "local",
      "family"
    ],
    "featuredShelf": true,
    "eddiesPick": false,
    "familyBrowseRecommended": true
  },
  {
    "id": "game-003",
    "title": "Basement Brawlers",
    "slug": "basement-brawlers",
    "description": "Party brawling with big readable characters and simple controls. This starter listing is sample data for the Eddie's Basement prototype. Replace it with verified official listings before public launch.",
    "shortDescription": "Party brawling with big readable characters and simple controls.",
    "officialUrl": "https://example.com/games/basement-brawlers",
    "coverImageUrl": "/covers/basement-brawlers.svg",
    "heroImageUrl": "/covers/basement-brawlers-hero.svg",
    "thumbnailUrl": "/covers/basement-brawlers.svg",
    "previewGifUrl": "/previews/basement-brawlers-preview.svg",
    "previewVideoPosterUrl": "/covers/basement-brawlers.svg",
    "screenshotUrls": [
      "/screens/basement-brawlers-screen-1.svg",
      "/screens/basement-brawlers-screen-2.svg"
    ],
    "mediaAttribution": "Prototype placeholder artwork generated for Eddie's Basement.",
    "mediaSourceUrl": "local-prototype-assets",
    "mediaStatus": "approved",
    "platforms": [
      "Browser",
      "Windows",
      "macOS"
    ],
    "genres": [
      "Party",
      "Fighting"
    ],
    "multiplayerTypes": [
      "Local",
      "Online",
      "Party"
    ],
    "playerCountMin": 2,
    "playerCountMax": 6,
    "isFreeToPlay": true,
    "requiresSubscription": false,
    "hasInAppPurchases": true,
    "hasPaidDLC": false,
    "downloadRequired": false,
    "accountRequired": false,
    "browserPlayable": true,
    "controllerFriendly": true,
    "crossPlatform": true,
    "monetizationLevel": "moderate",
    "freeStatus": "free_with_iap",
    "trustScore": 66,
    "sourceName": "Prototype seed data",
    "sourceUrl": "local://seed",
    "lastCheckedAt": "2026-07-10T00:00:00.000Z",
    "createdAt": "2026-07-10T00:00:00.000Z",
    "updatedAt": "2026-07-10T00:00:00.000Z",
    "tags": [
      "party",
      "controller"
    ],
    "featuredShelf": true,
    "eddiesPick": false,
    "familyBrowseRecommended": false
  },
  {
    "id": "game-004",
    "title": "Orbital Pizza Run",
    "slug": "orbital-pizza-run",
    "description": "Co-op delivery chaos in tiny space stations. This starter listing is sample data for the Eddie's Basement prototype. Replace it with verified official listings before public launch.",
    "shortDescription": "Co-op delivery chaos in tiny space stations.",
    "officialUrl": "https://example.com/games/orbital-pizza-run",
    "coverImageUrl": "/covers/orbital-pizza-run.svg",
    "heroImageUrl": "/covers/orbital-pizza-run-hero.svg",
    "thumbnailUrl": "/covers/orbital-pizza-run.svg",
    "previewGifUrl": "/previews/orbital-pizza-run-preview.svg",
    "previewVideoPosterUrl": "/covers/orbital-pizza-run.svg",
    "screenshotUrls": [
      "/screens/orbital-pizza-run-screen-1.svg",
      "/screens/orbital-pizza-run-screen-2.svg"
    ],
    "mediaAttribution": "Prototype placeholder artwork generated for Eddie's Basement.",
    "mediaSourceUrl": "local-prototype-assets",
    "mediaStatus": "approved",
    "platforms": [
      "Browser"
    ],
    "genres": [
      "Co-op",
      "Puzzle"
    ],
    "multiplayerTypes": [
      "Online",
      "Co-op"
    ],
    "playerCountMin": 2,
    "playerCountMax": 4,
    "isFreeToPlay": true,
    "requiresSubscription": false,
    "hasInAppPurchases": false,
    "hasPaidDLC": false,
    "downloadRequired": false,
    "accountRequired": false,
    "browserPlayable": true,
    "controllerFriendly": true,
    "crossPlatform": false,
    "monetizationLevel": "none",
    "freeStatus": "verified_free",
    "trustScore": 92,
    "sourceName": "Prototype seed data",
    "sourceUrl": "local://seed",
    "lastCheckedAt": "2026-07-10T00:00:00.000Z",
    "createdAt": "2026-07-10T00:00:00.000Z",
    "updatedAt": "2026-07-10T00:00:00.000Z",
    "tags": [
      "co-op",
      "no-signup"
    ],
    "featuredShelf": true,
    "eddiesPick": true,
    "familyBrowseRecommended": true
  },
  {
    "id": "game-005",
    "title": "Pixel Pond Hockey",
    "slug": "pixel-pond-hockey",
    "description": "Quick arcade sports matches with charming low-fi energy. This starter listing is sample data for the Eddie's Basement prototype. Replace it with verified official listings before public launch.",
    "shortDescription": "Quick arcade sports matches with charming low-fi energy.",
    "officialUrl": "https://example.com/games/pixel-pond-hockey",
    "coverImageUrl": "/covers/pixel-pond-hockey.svg",
    "heroImageUrl": "/covers/pixel-pond-hockey-hero.svg",
    "thumbnailUrl": "/covers/pixel-pond-hockey.svg",
    "previewGifUrl": "/previews/pixel-pond-hockey-preview.svg",
    "previewVideoPosterUrl": "/covers/pixel-pond-hockey.svg",
    "screenshotUrls": [
      "/screens/pixel-pond-hockey-screen-1.svg",
      "/screens/pixel-pond-hockey-screen-2.svg"
    ],
    "mediaAttribution": "Prototype placeholder artwork generated for Eddie's Basement.",
    "mediaSourceUrl": "local-prototype-assets",
    "mediaStatus": "approved",
    "platforms": [
      "Browser",
      "Mobile"
    ],
    "genres": [
      "Sports",
      "Arcade"
    ],
    "multiplayerTypes": [
      "Online",
      "Competitive"
    ],
    "playerCountMin": 2,
    "playerCountMax": 4,
    "isFreeToPlay": true,
    "requiresSubscription": false,
    "hasInAppPurchases": true,
    "hasPaidDLC": false,
    "downloadRequired": false,
    "accountRequired": false,
    "browserPlayable": true,
    "controllerFriendly": false,
    "crossPlatform": true,
    "monetizationLevel": "light",
    "freeStatus": "free_with_iap",
    "trustScore": 78,
    "sourceName": "Prototype seed data",
    "sourceUrl": "local://seed",
    "lastCheckedAt": "2026-07-10T00:00:00.000Z",
    "createdAt": "2026-07-10T00:00:00.000Z",
    "updatedAt": "2026-07-10T00:00:00.000Z",
    "tags": [
      "sports",
      "mobile"
    ],
    "featuredShelf": false,
    "eddiesPick": false,
    "familyBrowseRecommended": true
  },
  {
    "id": "game-006",
    "title": "Ghost LAN",
    "slug": "ghost-lan",
    "description": "A spooky team hide-and-seek game with short browser sessions. This starter listing is sample data for the Eddie's Basement prototype. Replace it with verified official listings before public launch.",
    "shortDescription": "A spooky team hide-and-seek game with short browser sessions.",
    "officialUrl": "https://example.com/games/ghost-lan",
    "coverImageUrl": "/covers/ghost-lan.svg",
    "heroImageUrl": "/covers/ghost-lan-hero.svg",
    "thumbnailUrl": "/covers/ghost-lan.svg",
    "previewGifUrl": "/previews/ghost-lan-preview.svg",
    "previewVideoPosterUrl": "/covers/ghost-lan.svg",
    "screenshotUrls": [
      "/screens/ghost-lan-screen-1.svg",
      "/screens/ghost-lan-screen-2.svg"
    ],
    "mediaAttribution": "Prototype placeholder artwork generated for Eddie's Basement.",
    "mediaSourceUrl": "local-prototype-assets",
    "mediaStatus": "approved",
    "platforms": [
      "Browser"
    ],
    "genres": [
      "Stealth",
      "Party"
    ],
    "multiplayerTypes": [
      "Online",
      "Team",
      "Party"
    ],
    "playerCountMin": 3,
    "playerCountMax": 10,
    "isFreeToPlay": true,
    "requiresSubscription": false,
    "hasInAppPurchases": false,
    "hasPaidDLC": false,
    "downloadRequired": false,
    "accountRequired": false,
    "browserPlayable": true,
    "controllerFriendly": false,
    "crossPlatform": false,
    "monetizationLevel": "none",
    "freeStatus": "verified_free",
    "trustScore": 92,
    "sourceName": "Prototype seed data",
    "sourceUrl": "local://seed",
    "lastCheckedAt": "2026-07-10T00:00:00.000Z",
    "createdAt": "2026-07-10T00:00:00.000Z",
    "updatedAt": "2026-07-10T00:00:00.000Z",
    "tags": [
      "browser",
      "groups"
    ],
    "featuredShelf": true,
    "eddiesPick": false,
    "familyBrowseRecommended": false
  },
  {
    "id": "game-007",
    "title": "Garage Kart Club",
    "slug": "garage-kart-club",
    "description": "Tiny kart racing with quick private rooms and controller support. This starter listing is sample data for the Eddie's Basement prototype. Replace it with verified official listings before public launch.",
    "shortDescription": "Tiny kart racing with quick private rooms and controller support.",
    "officialUrl": "https://example.com/games/garage-kart-club",
    "coverImageUrl": "/covers/garage-kart-club.svg",
    "heroImageUrl": "/covers/garage-kart-club-hero.svg",
    "thumbnailUrl": "/covers/garage-kart-club.svg",
    "previewGifUrl": "/previews/garage-kart-club-preview.svg",
    "previewVideoPosterUrl": "/covers/garage-kart-club.svg",
    "screenshotUrls": [
      "/screens/garage-kart-club-screen-1.svg",
      "/screens/garage-kart-club-screen-2.svg"
    ],
    "mediaAttribution": "Prototype placeholder artwork generated for Eddie's Basement.",
    "mediaSourceUrl": "local-prototype-assets",
    "mediaStatus": "approved",
    "platforms": [
      "Browser",
      "Windows"
    ],
    "genres": [
      "Racing",
      "Arcade"
    ],
    "multiplayerTypes": [
      "Online",
      "Competitive"
    ],
    "playerCountMin": 2,
    "playerCountMax": 8,
    "isFreeToPlay": true,
    "requiresSubscription": false,
    "hasInAppPurchases": true,
    "hasPaidDLC": true,
    "downloadRequired": false,
    "accountRequired": true,
    "browserPlayable": true,
    "controllerFriendly": true,
    "crossPlatform": true,
    "monetizationLevel": "moderate",
    "freeStatus": "free_with_iap",
    "trustScore": 66,
    "sourceName": "Prototype seed data",
    "sourceUrl": "local://seed",
    "lastCheckedAt": "2026-07-10T00:00:00.000Z",
    "createdAt": "2026-07-10T00:00:00.000Z",
    "updatedAt": "2026-07-10T00:00:00.000Z",
    "tags": [
      "racing",
      "controller"
    ],
    "featuredShelf": true,
    "eddiesPick": false,
    "familyBrowseRecommended": false
  },
  {
    "id": "game-008",
    "title": "Moonbase Mix-Up",
    "slug": "moonbase-mix-up",
    "description": "A social deduction-lite game that keeps rounds friendly and fast. This starter listing is sample data for the Eddie's Basement prototype. Replace it with verified official listings before public launch.",
    "shortDescription": "A social deduction-lite game that keeps rounds friendly and fast.",
    "officialUrl": "https://example.com/games/moonbase-mix-up",
    "coverImageUrl": "/covers/moonbase-mix-up.svg",
    "heroImageUrl": "/covers/moonbase-mix-up-hero.svg",
    "thumbnailUrl": "/covers/moonbase-mix-up.svg",
    "previewGifUrl": "/previews/moonbase-mix-up-preview.svg",
    "previewVideoPosterUrl": "/covers/moonbase-mix-up.svg",
    "screenshotUrls": [
      "/screens/moonbase-mix-up-screen-1.svg",
      "/screens/moonbase-mix-up-screen-2.svg"
    ],
    "mediaAttribution": "Prototype placeholder artwork generated for Eddie's Basement.",
    "mediaSourceUrl": "local-prototype-assets",
    "mediaStatus": "approved",
    "platforms": [
      "Browser",
      "Mobile"
    ],
    "genres": [
      "Social",
      "Party"
    ],
    "multiplayerTypes": [
      "Online",
      "Party"
    ],
    "playerCountMin": 4,
    "playerCountMax": 12,
    "isFreeToPlay": true,
    "requiresSubscription": false,
    "hasInAppPurchases": true,
    "hasPaidDLC": false,
    "downloadRequired": false,
    "accountRequired": false,
    "browserPlayable": true,
    "controllerFriendly": true,
    "crossPlatform": true,
    "monetizationLevel": "light",
    "freeStatus": "free_with_iap",
    "trustScore": 78,
    "sourceName": "Prototype seed data",
    "sourceUrl": "local://seed",
    "lastCheckedAt": "2026-07-10T00:00:00.000Z",
    "createdAt": "2026-07-10T00:00:00.000Z",
    "updatedAt": "2026-07-10T00:00:00.000Z",
    "tags": [
      "party",
      "phone-friendly"
    ],
    "featuredShelf": true,
    "eddiesPick": false,
    "familyBrowseRecommended": true
  },
  {
    "id": "game-009",
    "title": "Dungeon Doodles",
    "slug": "dungeon-doodles",
    "description": "Draw, guess, and survive silly fantasy prompts together. This starter listing is sample data for the Eddie's Basement prototype. Replace it with verified official listings before public launch.",
    "shortDescription": "Draw, guess, and survive silly fantasy prompts together.",
    "officialUrl": "https://example.com/games/dungeon-doodles",
    "coverImageUrl": "/covers/dungeon-doodles.svg",
    "heroImageUrl": "/covers/dungeon-doodles-hero.svg",
    "thumbnailUrl": "/covers/dungeon-doodles.svg",
    "previewGifUrl": "/previews/dungeon-doodles-preview.svg",
    "previewVideoPosterUrl": "/covers/dungeon-doodles.svg",
    "screenshotUrls": [
      "/screens/dungeon-doodles-screen-1.svg",
      "/screens/dungeon-doodles-screen-2.svg"
    ],
    "mediaAttribution": "Prototype placeholder artwork generated for Eddie's Basement.",
    "mediaSourceUrl": "local-prototype-assets",
    "mediaStatus": "approved",
    "platforms": [
      "Browser"
    ],
    "genres": [
      "Drawing",
      "Party"
    ],
    "multiplayerTypes": [
      "Online",
      "Party"
    ],
    "playerCountMin": 3,
    "playerCountMax": 16,
    "isFreeToPlay": true,
    "requiresSubscription": false,
    "hasInAppPurchases": false,
    "hasPaidDLC": false,
    "downloadRequired": false,
    "accountRequired": false,
    "browserPlayable": true,
    "controllerFriendly": false,
    "crossPlatform": false,
    "monetizationLevel": "none",
    "freeStatus": "verified_free",
    "trustScore": 92,
    "sourceName": "Prototype seed data",
    "sourceUrl": "local://seed",
    "lastCheckedAt": "2026-07-10T00:00:00.000Z",
    "createdAt": "2026-07-10T00:00:00.000Z",
    "updatedAt": "2026-07-10T00:00:00.000Z",
    "tags": [
      "drawing",
      "kids-can-browse"
    ],
    "featuredShelf": true,
    "eddiesPick": true,
    "familyBrowseRecommended": true
  },
  {
    "id": "game-010",
    "title": "Turbo Tiles",
    "slug": "turbo-tiles",
    "description": "Co-op puzzle boards where everyone moves pieces at once. This starter listing is sample data for the Eddie's Basement prototype. Replace it with verified official listings before public launch.",
    "shortDescription": "Co-op puzzle boards where everyone moves pieces at once.",
    "officialUrl": "https://example.com/games/turbo-tiles",
    "coverImageUrl": "/covers/turbo-tiles.svg",
    "heroImageUrl": "/covers/turbo-tiles-hero.svg",
    "thumbnailUrl": "/covers/turbo-tiles.svg",
    "previewGifUrl": "/previews/turbo-tiles-preview.svg",
    "previewVideoPosterUrl": "/covers/turbo-tiles.svg",
    "screenshotUrls": [
      "/screens/turbo-tiles-screen-1.svg",
      "/screens/turbo-tiles-screen-2.svg"
    ],
    "mediaAttribution": "Prototype placeholder artwork generated for Eddie's Basement.",
    "mediaSourceUrl": "local-prototype-assets",
    "mediaStatus": "approved",
    "platforms": [
      "Browser",
      "Mobile"
    ],
    "genres": [
      "Puzzle",
      "Co-op"
    ],
    "multiplayerTypes": [
      "Online",
      "Co-op"
    ],
    "playerCountMin": 2,
    "playerCountMax": 5,
    "isFreeToPlay": true,
    "requiresSubscription": false,
    "hasInAppPurchases": false,
    "hasPaidDLC": false,
    "downloadRequired": false,
    "accountRequired": false,
    "browserPlayable": true,
    "controllerFriendly": false,
    "crossPlatform": true,
    "monetizationLevel": "none",
    "freeStatus": "verified_free",
    "trustScore": 92,
    "sourceName": "Prototype seed data",
    "sourceUrl": "local://seed",
    "lastCheckedAt": "2026-07-10T00:00:00.000Z",
    "createdAt": "2026-07-10T00:00:00.000Z",
    "updatedAt": "2026-07-10T00:00:00.000Z",
    "tags": [
      "puzzle",
      "no-download"
    ],
    "featuredShelf": false,
    "eddiesPick": false,
    "familyBrowseRecommended": true
  },
  {
    "id": "game-011",
    "title": "Skyline Scramble",
    "slug": "skyline-scramble",
    "description": "Team platform races with goofy hazards and fast retries. This starter listing is sample data for the Eddie's Basement prototype. Replace it with verified official listings before public launch.",
    "shortDescription": "Team platform races with goofy hazards and fast retries.",
    "officialUrl": "https://example.com/games/skyline-scramble",
    "coverImageUrl": "/covers/skyline-scramble.svg",
    "heroImageUrl": "/covers/skyline-scramble-hero.svg",
    "thumbnailUrl": "/covers/skyline-scramble.svg",
    "previewGifUrl": "/previews/skyline-scramble-preview.svg",
    "previewVideoPosterUrl": "/covers/skyline-scramble.svg",
    "screenshotUrls": [
      "/screens/skyline-scramble-screen-1.svg",
      "/screens/skyline-scramble-screen-2.svg"
    ],
    "mediaAttribution": "Prototype placeholder artwork generated for Eddie's Basement.",
    "mediaSourceUrl": "local-prototype-assets",
    "mediaStatus": "approved",
    "platforms": [
      "Browser",
      "Windows",
      "macOS"
    ],
    "genres": [
      "Platformer",
      "Racing"
    ],
    "multiplayerTypes": [
      "Online",
      "Team"
    ],
    "playerCountMin": 2,
    "playerCountMax": 8,
    "isFreeToPlay": true,
    "requiresSubscription": false,
    "hasInAppPurchases": true,
    "hasPaidDLC": false,
    "downloadRequired": false,
    "accountRequired": false,
    "browserPlayable": true,
    "controllerFriendly": false,
    "crossPlatform": true,
    "monetizationLevel": "light",
    "freeStatus": "free_with_iap",
    "trustScore": 78,
    "sourceName": "Prototype seed data",
    "sourceUrl": "local://seed",
    "lastCheckedAt": "2026-07-10T00:00:00.000Z",
    "createdAt": "2026-07-10T00:00:00.000Z",
    "updatedAt": "2026-07-10T00:00:00.000Z",
    "tags": [
      "platformer",
      "team"
    ],
    "featuredShelf": false,
    "eddiesPick": false,
    "familyBrowseRecommended": false
  },
  {
    "id": "game-012",
    "title": "Cardboard Kingdoms",
    "slug": "cardboard-kingdoms",
    "description": "Light strategy card battles with friendly room codes. This starter listing is sample data for the Eddie's Basement prototype. Replace it with verified official listings before public launch.",
    "shortDescription": "Light strategy card battles with friendly room codes.",
    "officialUrl": "https://example.com/games/cardboard-kingdoms",
    "coverImageUrl": "/covers/cardboard-kingdoms.svg",
    "heroImageUrl": "/covers/cardboard-kingdoms-hero.svg",
    "thumbnailUrl": "/covers/cardboard-kingdoms.svg",
    "previewGifUrl": "/previews/cardboard-kingdoms-preview.svg",
    "previewVideoPosterUrl": "/covers/cardboard-kingdoms.svg",
    "screenshotUrls": [
      "/screens/cardboard-kingdoms-screen-1.svg",
      "/screens/cardboard-kingdoms-screen-2.svg"
    ],
    "mediaAttribution": "Prototype placeholder artwork generated for Eddie's Basement.",
    "mediaSourceUrl": "local-prototype-assets",
    "mediaStatus": "approved",
    "platforms": [
      "Browser"
    ],
    "genres": [
      "Card",
      "Strategy"
    ],
    "multiplayerTypes": [
      "Online",
      "Competitive"
    ],
    "playerCountMin": 2,
    "playerCountMax": 4,
    "isFreeToPlay": true,
    "requiresSubscription": false,
    "hasInAppPurchases": true,
    "hasPaidDLC": false,
    "downloadRequired": false,
    "accountRequired": false,
    "browserPlayable": true,
    "controllerFriendly": true,
    "crossPlatform": false,
    "monetizationLevel": "moderate",
    "freeStatus": "free_with_iap",
    "trustScore": 66,
    "sourceName": "Prototype seed data",
    "sourceUrl": "local://seed",
    "lastCheckedAt": "2026-07-10T00:00:00.000Z",
    "createdAt": "2026-07-10T00:00:00.000Z",
    "updatedAt": "2026-07-10T00:00:00.000Z",
    "tags": [
      "cards",
      "strategy"
    ],
    "featuredShelf": false,
    "eddiesPick": false,
    "familyBrowseRecommended": false
  },
  {
    "id": "game-013",
    "title": "Sidewalk Soccer",
    "slug": "sidewalk-soccer",
    "description": "Arcade soccer designed for quick 2v2 browser matches. This starter listing is sample data for the Eddie's Basement prototype. Replace it with verified official listings before public launch.",
    "shortDescription": "Arcade soccer designed for quick 2v2 browser matches.",
    "officialUrl": "https://example.com/games/sidewalk-soccer",
    "coverImageUrl": "/covers/sidewalk-soccer.svg",
    "heroImageUrl": "/covers/sidewalk-soccer-hero.svg",
    "thumbnailUrl": "/covers/sidewalk-soccer.svg",
    "previewGifUrl": "/previews/sidewalk-soccer-preview.svg",
    "previewVideoPosterUrl": "/covers/sidewalk-soccer.svg",
    "screenshotUrls": [
      "/screens/sidewalk-soccer-screen-1.svg",
      "/screens/sidewalk-soccer-screen-2.svg"
    ],
    "mediaAttribution": "Prototype placeholder artwork generated for Eddie's Basement.",
    "mediaSourceUrl": "local-prototype-assets",
    "mediaStatus": "approved",
    "platforms": [
      "Browser",
      "Mobile"
    ],
    "genres": [
      "Sports",
      "Arcade"
    ],
    "multiplayerTypes": [
      "Online",
      "Team"
    ],
    "playerCountMin": 2,
    "playerCountMax": 4,
    "isFreeToPlay": true,
    "requiresSubscription": false,
    "hasInAppPurchases": false,
    "hasPaidDLC": false,
    "downloadRequired": false,
    "accountRequired": false,
    "browserPlayable": true,
    "controllerFriendly": false,
    "crossPlatform": true,
    "monetizationLevel": "none",
    "freeStatus": "verified_free",
    "trustScore": 92,
    "sourceName": "Prototype seed data",
    "sourceUrl": "local://seed",
    "lastCheckedAt": "2026-07-10T00:00:00.000Z",
    "createdAt": "2026-07-10T00:00:00.000Z",
    "updatedAt": "2026-07-10T00:00:00.000Z",
    "tags": [
      "sports",
      "2v2"
    ],
    "featuredShelf": true,
    "eddiesPick": true,
    "familyBrowseRecommended": true
  },
  {
    "id": "game-014",
    "title": "Co-op Cove",
    "slug": "co-op-cove",
    "description": "A gentle shared-building game for players who want calm teamwork. This starter listing is sample data for the Eddie's Basement prototype. Replace it with verified official listings before public launch.",
    "shortDescription": "A gentle shared-building game for players who want calm teamwork.",
    "officialUrl": "https://example.com/games/co-op-cove",
    "coverImageUrl": "/covers/co-op-cove.svg",
    "heroImageUrl": "/covers/co-op-cove-hero.svg",
    "thumbnailUrl": "/covers/co-op-cove.svg",
    "previewGifUrl": "/previews/co-op-cove-preview.svg",
    "previewVideoPosterUrl": "/covers/co-op-cove.svg",
    "screenshotUrls": [
      "/screens/co-op-cove-screen-1.svg",
      "/screens/co-op-cove-screen-2.svg"
    ],
    "mediaAttribution": "Prototype placeholder artwork generated for Eddie's Basement.",
    "mediaSourceUrl": "local-prototype-assets",
    "mediaStatus": "approved",
    "platforms": [
      "Browser"
    ],
    "genres": [
      "Builder",
      "Co-op"
    ],
    "multiplayerTypes": [
      "Online",
      "Co-op"
    ],
    "playerCountMin": 2,
    "playerCountMax": 6,
    "isFreeToPlay": true,
    "requiresSubscription": false,
    "hasInAppPurchases": false,
    "hasPaidDLC": true,
    "downloadRequired": false,
    "accountRequired": false,
    "browserPlayable": true,
    "controllerFriendly": false,
    "crossPlatform": false,
    "monetizationLevel": "none",
    "freeStatus": "verified_free",
    "trustScore": 92,
    "sourceName": "Prototype seed data",
    "sourceUrl": "local://seed",
    "lastCheckedAt": "2026-07-10T00:00:00.000Z",
    "createdAt": "2026-07-10T00:00:00.000Z",
    "updatedAt": "2026-07-10T00:00:00.000Z",
    "tags": [
      "cozy",
      "co-op"
    ],
    "featuredShelf": true,
    "eddiesPick": false,
    "familyBrowseRecommended": true
  },
  {
    "id": "game-015",
    "title": "Robo Relay",
    "slug": "robo-relay",
    "description": "Team relay races where every player controls a different robot role. This starter listing is sample data for the Eddie's Basement prototype. Replace it with verified official listings before public launch.",
    "shortDescription": "Team relay races where every player controls a different robot role.",
    "officialUrl": "https://example.com/games/robo-relay",
    "coverImageUrl": "/covers/robo-relay.svg",
    "heroImageUrl": "/covers/robo-relay-hero.svg",
    "thumbnailUrl": "/covers/robo-relay.svg",
    "previewGifUrl": "/previews/robo-relay-preview.svg",
    "previewVideoPosterUrl": "/covers/robo-relay.svg",
    "screenshotUrls": [
      "/screens/robo-relay-screen-1.svg",
      "/screens/robo-relay-screen-2.svg"
    ],
    "mediaAttribution": "Prototype placeholder artwork generated for Eddie's Basement.",
    "mediaSourceUrl": "local-prototype-assets",
    "mediaStatus": "approved",
    "platforms": [
      "Browser",
      "Windows"
    ],
    "genres": [
      "Racing",
      "Co-op"
    ],
    "multiplayerTypes": [
      "Online",
      "Co-op",
      "Team"
    ],
    "playerCountMin": 2,
    "playerCountMax": 6,
    "isFreeToPlay": true,
    "requiresSubscription": false,
    "hasInAppPurchases": false,
    "hasPaidDLC": false,
    "downloadRequired": false,
    "accountRequired": true,
    "browserPlayable": true,
    "controllerFriendly": true,
    "crossPlatform": true,
    "monetizationLevel": "light",
    "freeStatus": "free_with_iap",
    "trustScore": 78,
    "sourceName": "Prototype seed data",
    "sourceUrl": "local://seed",
    "lastCheckedAt": "2026-07-10T00:00:00.000Z",
    "createdAt": "2026-07-10T00:00:00.000Z",
    "updatedAt": "2026-07-10T00:00:00.000Z",
    "tags": [
      "teamwork",
      "controller"
    ],
    "featuredShelf": false,
    "eddiesPick": false,
    "familyBrowseRecommended": false
  },
  {
    "id": "game-016",
    "title": "Arcade Ants",
    "slug": "arcade-ants",
    "description": "Tiny teams build, steal snacks, and defend the picnic blanket. This starter listing is sample data for the Eddie's Basement prototype. Replace it with verified official listings before public launch.",
    "shortDescription": "Tiny teams build, steal snacks, and defend the picnic blanket.",
    "officialUrl": "https://example.com/games/arcade-ants",
    "coverImageUrl": "/covers/arcade-ants.svg",
    "heroImageUrl": "/covers/arcade-ants-hero.svg",
    "thumbnailUrl": "/covers/arcade-ants.svg",
    "previewGifUrl": "/previews/arcade-ants-preview.svg",
    "previewVideoPosterUrl": "/covers/arcade-ants.svg",
    "screenshotUrls": [
      "/screens/arcade-ants-screen-1.svg",
      "/screens/arcade-ants-screen-2.svg"
    ],
    "mediaAttribution": "Prototype placeholder artwork generated for Eddie's Basement.",
    "mediaSourceUrl": "local-prototype-assets",
    "mediaStatus": "approved",
    "platforms": [
      "Browser"
    ],
    "genres": [
      "Strategy",
      "Party"
    ],
    "multiplayerTypes": [
      "Online",
      "Team",
      "Party"
    ],
    "playerCountMin": 2,
    "playerCountMax": 8,
    "isFreeToPlay": true,
    "requiresSubscription": false,
    "hasInAppPurchases": false,
    "hasPaidDLC": false,
    "downloadRequired": false,
    "accountRequired": false,
    "browserPlayable": true,
    "controllerFriendly": true,
    "crossPlatform": false,
    "monetizationLevel": "none",
    "freeStatus": "verified_free",
    "trustScore": 92,
    "sourceName": "Prototype seed data",
    "sourceUrl": "local://seed",
    "lastCheckedAt": "2026-07-10T00:00:00.000Z",
    "createdAt": "2026-07-10T00:00:00.000Z",
    "updatedAt": "2026-07-10T00:00:00.000Z",
    "tags": [
      "strategy",
      "group"
    ],
    "featuredShelf": true,
    "eddiesPick": false,
    "familyBrowseRecommended": true
  },
  {
    "id": "game-017",
    "title": "Junkyard Joust",
    "slug": "junkyard-joust",
    "description": "Scrappy competitive rounds with ridiculous homemade vehicles. This starter listing is sample data for the Eddie's Basement prototype. Replace it with verified official listings before public launch.",
    "shortDescription": "Scrappy competitive rounds with ridiculous homemade vehicles.",
    "officialUrl": "https://example.com/games/junkyard-joust",
    "coverImageUrl": "/covers/junkyard-joust.svg",
    "heroImageUrl": "/covers/junkyard-joust-hero.svg",
    "thumbnailUrl": "/covers/junkyard-joust.svg",
    "previewGifUrl": "/previews/junkyard-joust-preview.svg",
    "previewVideoPosterUrl": "/covers/junkyard-joust.svg",
    "screenshotUrls": [
      "/screens/junkyard-joust-screen-1.svg",
      "/screens/junkyard-joust-screen-2.svg"
    ],
    "mediaAttribution": "Prototype placeholder artwork generated for Eddie's Basement.",
    "mediaSourceUrl": "local-prototype-assets",
    "mediaStatus": "approved",
    "platforms": [
      "Browser",
      "Windows"
    ],
    "genres": [
      "Vehicle",
      "Action"
    ],
    "multiplayerTypes": [
      "Online",
      "Competitive"
    ],
    "playerCountMin": 2,
    "playerCountMax": 8,
    "isFreeToPlay": true,
    "requiresSubscription": false,
    "hasInAppPurchases": true,
    "hasPaidDLC": false,
    "downloadRequired": false,
    "accountRequired": true,
    "browserPlayable": true,
    "controllerFriendly": false,
    "crossPlatform": true,
    "monetizationLevel": "moderate",
    "freeStatus": "free_with_iap",
    "trustScore": 66,
    "sourceName": "Prototype seed data",
    "sourceUrl": "local://seed",
    "lastCheckedAt": "2026-07-10T00:00:00.000Z",
    "createdAt": "2026-07-10T00:00:00.000Z",
    "updatedAt": "2026-07-10T00:00:00.000Z",
    "tags": [
      "vehicle",
      "arena"
    ],
    "featuredShelf": false,
    "eddiesPick": false,
    "familyBrowseRecommended": false
  },
  {
    "id": "game-018",
    "title": "Lantern League",
    "slug": "lantern-league",
    "description": "A low-pressure team adventure built around short quests. This starter listing is sample data for the Eddie's Basement prototype. Replace it with verified official listings before public launch.",
    "shortDescription": "A low-pressure team adventure built around short quests.",
    "officialUrl": "https://example.com/games/lantern-league",
    "coverImageUrl": "/covers/lantern-league.svg",
    "heroImageUrl": "/covers/lantern-league-hero.svg",
    "thumbnailUrl": "/covers/lantern-league.svg",
    "previewGifUrl": "/previews/lantern-league-preview.svg",
    "previewVideoPosterUrl": "/covers/lantern-league.svg",
    "screenshotUrls": [
      "/screens/lantern-league-screen-1.svg",
      "/screens/lantern-league-screen-2.svg"
    ],
    "mediaAttribution": "Prototype placeholder artwork generated for Eddie's Basement.",
    "mediaSourceUrl": "local-prototype-assets",
    "mediaStatus": "approved",
    "platforms": [
      "Browser",
      "Mobile"
    ],
    "genres": [
      "Adventure",
      "Co-op"
    ],
    "multiplayerTypes": [
      "Online",
      "Co-op"
    ],
    "playerCountMin": 2,
    "playerCountMax": 5,
    "isFreeToPlay": true,
    "requiresSubscription": false,
    "hasInAppPurchases": true,
    "hasPaidDLC": false,
    "downloadRequired": false,
    "accountRequired": false,
    "browserPlayable": true,
    "controllerFriendly": false,
    "crossPlatform": true,
    "monetizationLevel": "light",
    "freeStatus": "free_with_iap",
    "trustScore": 78,
    "sourceName": "Prototype seed data",
    "sourceUrl": "local://seed",
    "lastCheckedAt": "2026-07-10T00:00:00.000Z",
    "createdAt": "2026-07-10T00:00:00.000Z",
    "updatedAt": "2026-07-10T00:00:00.000Z",
    "tags": [
      "adventure",
      "family"
    ],
    "featuredShelf": true,
    "eddiesPick": false,
    "familyBrowseRecommended": true
  },
  {
    "id": "game-019",
    "title": "Mini MMO Museum",
    "slug": "mini-mmo-museum",
    "description": "A tiny social MMO-style lobby with events and mini-games. This starter listing is sample data for the Eddie's Basement prototype. Replace it with verified official listings before public launch.",
    "shortDescription": "A tiny social MMO-style lobby with events and mini-games.",
    "officialUrl": "https://example.com/games/mini-mmo-museum",
    "coverImageUrl": "/covers/mini-mmo-museum.svg",
    "heroImageUrl": "/covers/mini-mmo-museum-hero.svg",
    "thumbnailUrl": "/covers/mini-mmo-museum.svg",
    "previewVideoPosterUrl": "/covers/mini-mmo-museum.svg",
    "screenshotUrls": [
      "/screens/mini-mmo-museum-screen-1.svg",
      "/screens/mini-mmo-museum-screen-2.svg"
    ],
    "mediaAttribution": "Prototype placeholder artwork generated for Eddie's Basement.",
    "mediaSourceUrl": "local-prototype-assets",
    "mediaStatus": "approved",
    "platforms": [
      "Browser"
    ],
    "genres": [
      "MMO",
      "Social"
    ],
    "multiplayerTypes": [
      "Online",
      "MMO",
      "Social"
    ],
    "playerCountMin": 2,
    "playerCountMax": 30,
    "isFreeToPlay": true,
    "requiresSubscription": false,
    "hasInAppPurchases": true,
    "hasPaidDLC": false,
    "downloadRequired": false,
    "accountRequired": false,
    "browserPlayable": true,
    "controllerFriendly": false,
    "crossPlatform": false,
    "monetizationLevel": "moderate",
    "freeStatus": "free_with_iap",
    "trustScore": 66,
    "sourceName": "Prototype seed data",
    "sourceUrl": "local://seed",
    "lastCheckedAt": "2026-07-10T00:00:00.000Z",
    "createdAt": "2026-07-10T00:00:00.000Z",
    "updatedAt": "2026-07-10T00:00:00.000Z",
    "tags": [
      "mmo",
      "social"
    ],
    "featuredShelf": false,
    "eddiesPick": false,
    "familyBrowseRecommended": false
  },
  {
    "id": "game-020",
    "title": "Friday Night Dice",
    "slug": "friday-night-dice",
    "description": "Browser board-game night with quick dice games and room codes. This starter listing is sample data for the Eddie's Basement prototype. Replace it with verified official listings before public launch.",
    "shortDescription": "Browser board-game night with quick dice games and room codes.",
    "officialUrl": "https://example.com/games/friday-night-dice",
    "coverImageUrl": "/covers/friday-night-dice.svg",
    "heroImageUrl": "/covers/friday-night-dice-hero.svg",
    "thumbnailUrl": "/covers/friday-night-dice.svg",
    "previewVideoPosterUrl": "/covers/friday-night-dice.svg",
    "screenshotUrls": [
      "/screens/friday-night-dice-screen-1.svg",
      "/screens/friday-night-dice-screen-2.svg"
    ],
    "mediaAttribution": "Prototype placeholder artwork generated for Eddie's Basement.",
    "mediaSourceUrl": "local-prototype-assets",
    "mediaStatus": "approved",
    "platforms": [
      "Browser"
    ],
    "genres": [
      "Board",
      "Party"
    ],
    "multiplayerTypes": [
      "Online",
      "Party"
    ],
    "playerCountMin": 2,
    "playerCountMax": 8,
    "isFreeToPlay": true,
    "requiresSubscription": false,
    "hasInAppPurchases": false,
    "hasPaidDLC": false,
    "downloadRequired": false,
    "accountRequired": false,
    "browserPlayable": true,
    "controllerFriendly": true,
    "crossPlatform": false,
    "monetizationLevel": "none",
    "freeStatus": "verified_free",
    "trustScore": 92,
    "sourceName": "Prototype seed data",
    "sourceUrl": "local://seed",
    "lastCheckedAt": "2026-07-10T00:00:00.000Z",
    "createdAt": "2026-07-10T00:00:00.000Z",
    "updatedAt": "2026-07-10T00:00:00.000Z",
    "tags": [
      "board-game",
      "no-signup"
    ],
    "featuredShelf": true,
    "eddiesPick": true,
    "familyBrowseRecommended": true
  },
  {
    "id": "game-021",
    "title": "Laser Library",
    "slug": "laser-library",
    "description": "Hide, chase, and collect books in a neon library maze. This starter listing is sample data for the Eddie's Basement prototype. Replace it with verified official listings before public launch.",
    "shortDescription": "Hide, chase, and collect books in a neon library maze.",
    "officialUrl": "https://example.com/games/laser-library",
    "coverImageUrl": "/covers/laser-library.svg",
    "heroImageUrl": "/covers/laser-library-hero.svg",
    "thumbnailUrl": "/covers/laser-library.svg",
    "previewVideoPosterUrl": "/covers/laser-library.svg",
    "screenshotUrls": [
      "/screens/laser-library-screen-1.svg",
      "/screens/laser-library-screen-2.svg"
    ],
    "mediaAttribution": "Prototype placeholder artwork generated for Eddie's Basement.",
    "mediaSourceUrl": "local-prototype-assets",
    "mediaStatus": "approved",
    "platforms": [
      "Browser"
    ],
    "genres": [
      "Maze",
      "Party"
    ],
    "multiplayerTypes": [
      "Online",
      "Party"
    ],
    "playerCountMin": 2,
    "playerCountMax": 10,
    "isFreeToPlay": true,
    "requiresSubscription": false,
    "hasInAppPurchases": false,
    "hasPaidDLC": true,
    "downloadRequired": false,
    "accountRequired": false,
    "browserPlayable": true,
    "controllerFriendly": false,
    "crossPlatform": false,
    "monetizationLevel": "none",
    "freeStatus": "verified_free",
    "trustScore": 92,
    "sourceName": "Prototype seed data",
    "sourceUrl": "local://seed",
    "lastCheckedAt": "2026-07-10T00:00:00.000Z",
    "createdAt": "2026-07-10T00:00:00.000Z",
    "updatedAt": "2026-07-10T00:00:00.000Z",
    "tags": [
      "maze",
      "quick"
    ],
    "featuredShelf": true,
    "eddiesPick": false,
    "familyBrowseRecommended": false
  },
  {
    "id": "game-022",
    "title": "Backyard Boss Fight",
    "slug": "backyard-boss-fight",
    "description": "A goofy co-op boss rush where everyone gets a job. This starter listing is sample data for the Eddie's Basement prototype. Replace it with verified official listings before public launch.",
    "shortDescription": "A goofy co-op boss rush where everyone gets a job.",
    "officialUrl": "https://example.com/games/backyard-boss-fight",
    "coverImageUrl": "/covers/backyard-boss-fight.svg",
    "heroImageUrl": "/covers/backyard-boss-fight-hero.svg",
    "thumbnailUrl": "/covers/backyard-boss-fight.svg",
    "previewVideoPosterUrl": "/covers/backyard-boss-fight.svg",
    "screenshotUrls": [
      "/screens/backyard-boss-fight-screen-1.svg",
      "/screens/backyard-boss-fight-screen-2.svg"
    ],
    "mediaAttribution": "Prototype placeholder artwork generated for Eddie's Basement.",
    "mediaSourceUrl": "local-prototype-assets",
    "mediaStatus": "approved",
    "platforms": [
      "Browser",
      "Windows"
    ],
    "genres": [
      "Action",
      "Co-op"
    ],
    "multiplayerTypes": [
      "Online",
      "Co-op"
    ],
    "playerCountMin": 2,
    "playerCountMax": 4,
    "isFreeToPlay": true,
    "requiresSubscription": false,
    "hasInAppPurchases": true,
    "hasPaidDLC": false,
    "downloadRequired": false,
    "accountRequired": true,
    "browserPlayable": true,
    "controllerFriendly": false,
    "crossPlatform": true,
    "monetizationLevel": "light",
    "freeStatus": "free_with_iap",
    "trustScore": 78,
    "sourceName": "Prototype seed data",
    "sourceUrl": "local://seed",
    "lastCheckedAt": "2026-07-10T00:00:00.000Z",
    "createdAt": "2026-07-10T00:00:00.000Z",
    "updatedAt": "2026-07-10T00:00:00.000Z",
    "tags": [
      "boss-rush",
      "co-op"
    ],
    "featuredShelf": false,
    "eddiesPick": false,
    "familyBrowseRecommended": false
  },
  {
    "id": "game-023",
    "title": "Snack Stackers",
    "slug": "snack-stackers",
    "description": "A family-friendly physics stacking game for teams. This starter listing is sample data for the Eddie's Basement prototype. Replace it with verified official listings before public launch.",
    "shortDescription": "A family-friendly physics stacking game for teams.",
    "officialUrl": "https://example.com/games/snack-stackers",
    "coverImageUrl": "/covers/snack-stackers.svg",
    "heroImageUrl": "/covers/snack-stackers-hero.svg",
    "thumbnailUrl": "/covers/snack-stackers.svg",
    "previewVideoPosterUrl": "/covers/snack-stackers.svg",
    "screenshotUrls": [
      "/screens/snack-stackers-screen-1.svg",
      "/screens/snack-stackers-screen-2.svg"
    ],
    "mediaAttribution": "Prototype placeholder artwork generated for Eddie's Basement.",
    "mediaSourceUrl": "local-prototype-assets",
    "mediaStatus": "approved",
    "platforms": [
      "Browser",
      "Mobile"
    ],
    "genres": [
      "Physics",
      "Party"
    ],
    "multiplayerTypes": [
      "Online",
      "Party",
      "Co-op"
    ],
    "playerCountMin": 2,
    "playerCountMax": 8,
    "isFreeToPlay": true,
    "requiresSubscription": false,
    "hasInAppPurchases": false,
    "hasPaidDLC": false,
    "downloadRequired": false,
    "accountRequired": false,
    "browserPlayable": true,
    "controllerFriendly": false,
    "crossPlatform": true,
    "monetizationLevel": "none",
    "freeStatus": "verified_free",
    "trustScore": 92,
    "sourceName": "Prototype seed data",
    "sourceUrl": "local://seed",
    "lastCheckedAt": "2026-07-10T00:00:00.000Z",
    "createdAt": "2026-07-10T00:00:00.000Z",
    "updatedAt": "2026-07-10T00:00:00.000Z",
    "tags": [
      "physics",
      "family"
    ],
    "featuredShelf": true,
    "eddiesPick": false,
    "familyBrowseRecommended": true
  },
  {
    "id": "game-024",
    "title": "VHS Volleyball",
    "slug": "vhs-volleyball",
    "description": "Retro arcade volleyball with couch and online modes. This starter listing is sample data for the Eddie's Basement prototype. Replace it with verified official listings before public launch.",
    "shortDescription": "Retro arcade volleyball with couch and online modes.",
    "officialUrl": "https://example.com/games/vhs-volleyball",
    "coverImageUrl": "/covers/vhs-volleyball.svg",
    "heroImageUrl": "/covers/vhs-volleyball-hero.svg",
    "thumbnailUrl": "/covers/vhs-volleyball.svg",
    "previewVideoPosterUrl": "/covers/vhs-volleyball.svg",
    "screenshotUrls": [
      "/screens/vhs-volleyball-screen-1.svg",
      "/screens/vhs-volleyball-screen-2.svg"
    ],
    "mediaAttribution": "Prototype placeholder artwork generated for Eddie's Basement.",
    "mediaSourceUrl": "local-prototype-assets",
    "mediaStatus": "approved",
    "platforms": [
      "Browser",
      "Windows",
      "macOS"
    ],
    "genres": [
      "Sports",
      "Retro"
    ],
    "multiplayerTypes": [
      "Local",
      "Online",
      "Competitive"
    ],
    "playerCountMin": 2,
    "playerCountMax": 4,
    "isFreeToPlay": true,
    "requiresSubscription": false,
    "hasInAppPurchases": true,
    "hasPaidDLC": false,
    "downloadRequired": false,
    "accountRequired": true,
    "browserPlayable": true,
    "controllerFriendly": true,
    "crossPlatform": true,
    "monetizationLevel": "light",
    "freeStatus": "free_with_iap",
    "trustScore": 78,
    "sourceName": "Prototype seed data",
    "sourceUrl": "local://seed",
    "lastCheckedAt": "2026-07-10T00:00:00.000Z",
    "createdAt": "2026-07-10T00:00:00.000Z",
    "updatedAt": "2026-07-10T00:00:00.000Z",
    "tags": [
      "retro",
      "sports"
    ],
    "featuredShelf": true,
    "eddiesPick": true,
    "familyBrowseRecommended": true
  },
  {
    "id": "game-025",
    "title": "Quest Queue",
    "slug": "quest-queue",
    "description": "Co-op quest cards built for low commitment friend groups. This starter listing is sample data for the Eddie's Basement prototype. Replace it with verified official listings before public launch.",
    "shortDescription": "Co-op quest cards built for low commitment friend groups.",
    "officialUrl": "https://example.com/games/quest-queue",
    "coverImageUrl": "/covers/quest-queue.svg",
    "heroImageUrl": "/covers/quest-queue-hero.svg",
    "thumbnailUrl": "/covers/quest-queue.svg",
    "previewVideoPosterUrl": "/covers/quest-queue.svg",
    "screenshotUrls": [
      "/screens/quest-queue-screen-1.svg",
      "/screens/quest-queue-screen-2.svg"
    ],
    "mediaAttribution": "Prototype placeholder artwork generated for Eddie's Basement.",
    "mediaSourceUrl": "local-prototype-assets",
    "mediaStatus": "approved",
    "platforms": [
      "Browser"
    ],
    "genres": [
      "Adventure",
      "Card"
    ],
    "multiplayerTypes": [
      "Online",
      "Co-op"
    ],
    "playerCountMin": 2,
    "playerCountMax": 6,
    "isFreeToPlay": true,
    "requiresSubscription": false,
    "hasInAppPurchases": false,
    "hasPaidDLC": false,
    "downloadRequired": false,
    "accountRequired": false,
    "browserPlayable": true,
    "controllerFriendly": false,
    "crossPlatform": false,
    "monetizationLevel": "none",
    "freeStatus": "verified_free",
    "trustScore": 92,
    "sourceName": "Prototype seed data",
    "sourceUrl": "local://seed",
    "lastCheckedAt": "2026-07-10T00:00:00.000Z",
    "createdAt": "2026-07-10T00:00:00.000Z",
    "updatedAt": "2026-07-10T00:00:00.000Z",
    "tags": [
      "cards",
      "co-op"
    ],
    "featuredShelf": false,
    "eddiesPick": false,
    "familyBrowseRecommended": true
  },
  {
    "id": "game-026",
    "title": "Cosmic Tag",
    "slug": "cosmic-tag",
    "description": "Classic tag with portals, gravity pads, and private rooms. This starter listing is sample data for the Eddie's Basement prototype. Replace it with verified official listings before public launch.",
    "shortDescription": "Classic tag with portals, gravity pads, and private rooms.",
    "officialUrl": "https://example.com/games/cosmic-tag",
    "coverImageUrl": "/covers/cosmic-tag.svg",
    "heroImageUrl": "/covers/cosmic-tag-hero.svg",
    "thumbnailUrl": "/covers/cosmic-tag.svg",
    "previewVideoPosterUrl": "/covers/cosmic-tag.svg",
    "screenshotUrls": [
      "/screens/cosmic-tag-screen-1.svg",
      "/screens/cosmic-tag-screen-2.svg"
    ],
    "mediaAttribution": "Prototype placeholder artwork generated for Eddie's Basement.",
    "mediaSourceUrl": "local-prototype-assets",
    "mediaStatus": "approved",
    "platforms": [
      "Browser"
    ],
    "genres": [
      "Action",
      "Party"
    ],
    "multiplayerTypes": [
      "Online",
      "Party"
    ],
    "playerCountMin": 3,
    "playerCountMax": 12,
    "isFreeToPlay": true,
    "requiresSubscription": false,
    "hasInAppPurchases": false,
    "hasPaidDLC": false,
    "downloadRequired": false,
    "accountRequired": false,
    "browserPlayable": true,
    "controllerFriendly": false,
    "crossPlatform": false,
    "monetizationLevel": "none",
    "freeStatus": "verified_free",
    "trustScore": 92,
    "sourceName": "Prototype seed data",
    "sourceUrl": "local://seed",
    "lastCheckedAt": "2026-07-10T00:00:00.000Z",
    "createdAt": "2026-07-10T00:00:00.000Z",
    "updatedAt": "2026-07-10T00:00:00.000Z",
    "tags": [
      "tag",
      "groups"
    ],
    "featuredShelf": true,
    "eddiesPick": false,
    "familyBrowseRecommended": true
  },
  {
    "id": "game-027",
    "title": "Tower Trouble",
    "slug": "tower-trouble",
    "description": "Two-player tower defense where both players build under pressure. This starter listing is sample data for the Eddie's Basement prototype. Replace it with verified official listings before public launch.",
    "shortDescription": "Two-player tower defense where both players build under pressure.",
    "officialUrl": "https://example.com/games/tower-trouble",
    "coverImageUrl": "/covers/tower-trouble.svg",
    "heroImageUrl": "/covers/tower-trouble-hero.svg",
    "thumbnailUrl": "/covers/tower-trouble.svg",
    "previewVideoPosterUrl": "/covers/tower-trouble.svg",
    "screenshotUrls": [
      "/screens/tower-trouble-screen-1.svg",
      "/screens/tower-trouble-screen-2.svg"
    ],
    "mediaAttribution": "Prototype placeholder artwork generated for Eddie's Basement.",
    "mediaSourceUrl": "local-prototype-assets",
    "mediaStatus": "approved",
    "platforms": [
      "Browser",
      "Mobile"
    ],
    "genres": [
      "Defense",
      "Strategy"
    ],
    "multiplayerTypes": [
      "Online",
      "Co-op"
    ],
    "playerCountMin": 2,
    "playerCountMax": 2,
    "isFreeToPlay": true,
    "requiresSubscription": false,
    "hasInAppPurchases": true,
    "hasPaidDLC": false,
    "downloadRequired": false,
    "accountRequired": false,
    "browserPlayable": true,
    "controllerFriendly": false,
    "crossPlatform": true,
    "monetizationLevel": "light",
    "freeStatus": "free_with_iap",
    "trustScore": 78,
    "sourceName": "Prototype seed data",
    "sourceUrl": "local://seed",
    "lastCheckedAt": "2026-07-10T00:00:00.000Z",
    "createdAt": "2026-07-10T00:00:00.000Z",
    "updatedAt": "2026-07-10T00:00:00.000Z",
    "tags": [
      "2-player",
      "strategy"
    ],
    "featuredShelf": false,
    "eddiesPick": false,
    "familyBrowseRecommended": true
  },
  {
    "id": "game-028",
    "title": "Retro Room Racers",
    "slug": "retro-room-racers",
    "description": "Top-down room-code racing for quick family tournaments. This starter listing is sample data for the Eddie's Basement prototype. Replace it with verified official listings before public launch.",
    "shortDescription": "Top-down room-code racing for quick family tournaments.",
    "officialUrl": "https://example.com/games/retro-room-racers",
    "coverImageUrl": "/covers/retro-room-racers.svg",
    "heroImageUrl": "/covers/retro-room-racers-hero.svg",
    "thumbnailUrl": "/covers/retro-room-racers.svg",
    "previewVideoPosterUrl": "/covers/retro-room-racers.svg",
    "screenshotUrls": [
      "/screens/retro-room-racers-screen-1.svg",
      "/screens/retro-room-racers-screen-2.svg"
    ],
    "mediaAttribution": "Prototype placeholder artwork generated for Eddie's Basement.",
    "mediaSourceUrl": "local-prototype-assets",
    "mediaStatus": "approved",
    "platforms": [
      "Browser"
    ],
    "genres": [
      "Racing",
      "Retro"
    ],
    "multiplayerTypes": [
      "Online",
      "Party"
    ],
    "playerCountMin": 2,
    "playerCountMax": 8,
    "isFreeToPlay": true,
    "requiresSubscription": false,
    "hasInAppPurchases": false,
    "hasPaidDLC": true,
    "downloadRequired": false,
    "accountRequired": false,
    "browserPlayable": true,
    "controllerFriendly": true,
    "crossPlatform": false,
    "monetizationLevel": "none",
    "freeStatus": "verified_free",
    "trustScore": 92,
    "sourceName": "Prototype seed data",
    "sourceUrl": "local://seed",
    "lastCheckedAt": "2026-07-10T00:00:00.000Z",
    "createdAt": "2026-07-10T00:00:00.000Z",
    "updatedAt": "2026-07-10T00:00:00.000Z",
    "tags": [
      "racing",
      "party"
    ],
    "featuredShelf": true,
    "eddiesPick": false,
    "familyBrowseRecommended": true
  },
  {
    "id": "game-029",
    "title": "Monster Mailroom",
    "slug": "monster-mailroom",
    "description": "Sort chaotic packages together before the monsters arrive. This starter listing is sample data for the Eddie's Basement prototype. Replace it with verified official listings before public launch.",
    "shortDescription": "Sort chaotic packages together before the monsters arrive.",
    "officialUrl": "https://example.com/games/monster-mailroom",
    "coverImageUrl": "/covers/monster-mailroom.svg",
    "heroImageUrl": "/covers/monster-mailroom-hero.svg",
    "thumbnailUrl": "/covers/monster-mailroom.svg",
    "previewVideoPosterUrl": "/covers/monster-mailroom.svg",
    "screenshotUrls": [
      "/screens/monster-mailroom-screen-1.svg",
      "/screens/monster-mailroom-screen-2.svg"
    ],
    "mediaAttribution": "Prototype placeholder artwork generated for Eddie's Basement.",
    "mediaSourceUrl": "local-prototype-assets",
    "mediaStatus": "approved",
    "platforms": [
      "Browser",
      "Windows"
    ],
    "genres": [
      "Co-op",
      "Time Management"
    ],
    "multiplayerTypes": [
      "Local",
      "Co-op"
    ],
    "playerCountMin": 2,
    "playerCountMax": 4,
    "isFreeToPlay": true,
    "requiresSubscription": false,
    "hasInAppPurchases": true,
    "hasPaidDLC": false,
    "downloadRequired": false,
    "accountRequired": true,
    "browserPlayable": true,
    "controllerFriendly": true,
    "crossPlatform": true,
    "monetizationLevel": "light",
    "freeStatus": "free_with_iap",
    "trustScore": 78,
    "sourceName": "Prototype seed data",
    "sourceUrl": "local://seed",
    "lastCheckedAt": "2026-07-10T00:00:00.000Z",
    "createdAt": "2026-07-10T00:00:00.000Z",
    "updatedAt": "2026-07-10T00:00:00.000Z",
    "tags": [
      "local",
      "teamwork"
    ],
    "featuredShelf": false,
    "eddiesPick": false,
    "familyBrowseRecommended": true
  },
  {
    "id": "game-030",
    "title": "Basement Blitz",
    "slug": "basement-blitz",
    "description": "Competitive mini-game playlist for quick Friday night sessions. This starter listing is sample data for the Eddie's Basement prototype. Replace it with verified official listings before public launch.",
    "shortDescription": "Competitive mini-game playlist for quick Friday night sessions.",
    "officialUrl": "https://example.com/games/basement-blitz",
    "coverImageUrl": "/covers/basement-blitz.svg",
    "heroImageUrl": "/covers/basement-blitz-hero.svg",
    "thumbnailUrl": "/covers/basement-blitz.svg",
    "previewVideoPosterUrl": "/covers/basement-blitz.svg",
    "screenshotUrls": [
      "/screens/basement-blitz-screen-1.svg",
      "/screens/basement-blitz-screen-2.svg"
    ],
    "mediaAttribution": "Prototype placeholder artwork generated for Eddie's Basement.",
    "mediaSourceUrl": "local-prototype-assets",
    "mediaStatus": "approved",
    "platforms": [
      "Browser",
      "Mobile"
    ],
    "genres": [
      "Party",
      "Mini-games"
    ],
    "multiplayerTypes": [
      "Online",
      "Party"
    ],
    "playerCountMin": 3,
    "playerCountMax": 12,
    "isFreeToPlay": true,
    "requiresSubscription": false,
    "hasInAppPurchases": false,
    "hasPaidDLC": false,
    "downloadRequired": false,
    "accountRequired": false,
    "browserPlayable": true,
    "controllerFriendly": false,
    "crossPlatform": true,
    "monetizationLevel": "none",
    "freeStatus": "verified_free",
    "trustScore": 92,
    "sourceName": "Prototype seed data",
    "sourceUrl": "local://seed",
    "lastCheckedAt": "2026-07-10T00:00:00.000Z",
    "createdAt": "2026-07-10T00:00:00.000Z",
    "updatedAt": "2026-07-10T00:00:00.000Z",
    "tags": [
      "mini-games",
      "group"
    ],
    "featuredShelf": true,
    "eddiesPick": true,
    "familyBrowseRecommended": true
  },
  {
    "id": "game-031",
    "title": "Trial Trap Arena",
    "slug": "trial-trap-arena",
    "description": "Questionable sample listing used to prove that Eddie's Basement hides fake-free games from default results.",
    "shortDescription": "Questionable listing hidden from default Actually Free results.",
    "officialUrl": "https://example.com/games/trial-trap-arena",
    "coverImageUrl": "/covers/trial-trap-arena.svg",
    "heroImageUrl": "/covers/trial-trap-arena-hero.svg",
    "thumbnailUrl": "/covers/trial-trap-arena.svg",
    "previewVideoPosterUrl": "/covers/trial-trap-arena.svg",
    "screenshotUrls": [
      "/screens/trial-trap-arena-screen-1.svg"
    ],
    "mediaAttribution": "Prototype placeholder artwork generated for Eddie's Basement.",
    "mediaSourceUrl": "local-prototype-assets",
    "mediaStatus": "approved",
    "platforms": [
      "Browser"
    ],
    "genres": [
      "Action"
    ],
    "multiplayerTypes": [
      "Online"
    ],
    "playerCountMin": 2,
    "playerCountMax": 8,
    "isFreeToPlay": true,
    "requiresSubscription": false,
    "hasInAppPurchases": true,
    "hasPaidDLC": true,
    "downloadRequired": false,
    "accountRequired": true,
    "browserPlayable": true,
    "controllerFriendly": false,
    "crossPlatform": false,
    "monetizationLevel": "heavy",
    "freeStatus": "free_trial_only",
    "trustScore": 20,
    "sourceName": "Prototype seed data",
    "sourceUrl": "local://seed",
    "lastCheckedAt": "2026-07-10T00:00:00.000Z",
    "createdAt": "2026-07-10T00:00:00.000Z",
    "updatedAt": "2026-07-10T00:00:00.000Z",
    "tags": [
      "hidden",
      "questionable"
    ],
    "featuredShelf": false,
    "eddiesPick": false,
    "familyBrowseRecommended": false
  },
  {
    "id": "game-032",
    "title": "Subscription Squad",
    "slug": "subscription-squad",
    "description": "Questionable sample listing used to prove that Eddie's Basement hides fake-free games from default results.",
    "shortDescription": "Questionable listing hidden from default Actually Free results.",
    "officialUrl": "https://example.com/games/subscription-squad",
    "coverImageUrl": "/covers/subscription-squad.svg",
    "heroImageUrl": "/covers/subscription-squad-hero.svg",
    "thumbnailUrl": "/covers/subscription-squad.svg",
    "previewVideoPosterUrl": "/covers/subscription-squad.svg",
    "screenshotUrls": [
      "/screens/subscription-squad-screen-1.svg"
    ],
    "mediaAttribution": "Prototype placeholder artwork generated for Eddie's Basement.",
    "mediaSourceUrl": "local-prototype-assets",
    "mediaStatus": "approved",
    "platforms": [
      "Browser"
    ],
    "genres": [
      "Action"
    ],
    "multiplayerTypes": [
      "Online"
    ],
    "playerCountMin": 2,
    "playerCountMax": 8,
    "isFreeToPlay": false,
    "requiresSubscription": true,
    "hasInAppPurchases": true,
    "hasPaidDLC": true,
    "downloadRequired": false,
    "accountRequired": true,
    "browserPlayable": true,
    "controllerFriendly": false,
    "crossPlatform": false,
    "monetizationLevel": "heavy",
    "freeStatus": "subscription_required",
    "trustScore": 20,
    "sourceName": "Prototype seed data",
    "sourceUrl": "local://seed",
    "lastCheckedAt": "2026-07-10T00:00:00.000Z",
    "createdAt": "2026-07-10T00:00:00.000Z",
    "updatedAt": "2026-07-10T00:00:00.000Z",
    "tags": [
      "hidden",
      "questionable"
    ],
    "featuredShelf": false,
    "eddiesPick": false,
    "familyBrowseRecommended": false
  },
  {
    "id": "game-033",
    "title": "Mystery Paywall MMO",
    "slug": "mystery-paywall-mmo",
    "description": "Questionable sample listing used to prove that Eddie's Basement hides fake-free games from default results.",
    "shortDescription": "Questionable listing hidden from default Actually Free results.",
    "officialUrl": "https://example.com/games/mystery-paywall-mmo",
    "coverImageUrl": "/covers/mystery-paywall-mmo.svg",
    "heroImageUrl": "/covers/mystery-paywall-mmo-hero.svg",
    "thumbnailUrl": "/covers/mystery-paywall-mmo.svg",
    "previewVideoPosterUrl": "/covers/mystery-paywall-mmo.svg",
    "screenshotUrls": [
      "/screens/mystery-paywall-mmo-screen-1.svg"
    ],
    "mediaAttribution": "Prototype placeholder artwork generated for Eddie's Basement.",
    "mediaSourceUrl": "local-prototype-assets",
    "mediaStatus": "approved",
    "platforms": [
      "Browser"
    ],
    "genres": [
      "Action"
    ],
    "multiplayerTypes": [
      "Online"
    ],
    "playerCountMin": 2,
    "playerCountMax": 8,
    "isFreeToPlay": true,
    "requiresSubscription": false,
    "hasInAppPurchases": true,
    "hasPaidDLC": true,
    "downloadRequired": false,
    "accountRequired": true,
    "browserPlayable": true,
    "controllerFriendly": false,
    "crossPlatform": false,
    "monetizationLevel": "unknown",
    "freeStatus": "unknown",
    "trustScore": 20,
    "sourceName": "Prototype seed data",
    "sourceUrl": "local://seed",
    "lastCheckedAt": "2026-07-10T00:00:00.000Z",
    "createdAt": "2026-07-10T00:00:00.000Z",
    "updatedAt": "2026-07-10T00:00:00.000Z",
    "tags": [
      "hidden",
      "questionable"
    ],
    "featuredShelf": false,
    "eddiesPick": false,
    "familyBrowseRecommended": false
  }
];

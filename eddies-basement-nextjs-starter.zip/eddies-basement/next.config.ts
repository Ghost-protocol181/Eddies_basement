import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  reactStrictMode: true,
  images: {
    remotePatterns: [
      {
        protocol: "https",
        hostname: "images.unsplash.com"
      },
      {
        protocol: "https",
        hostname: "cdn.cloudflare.steamstatic.com"
      },
      {
        protocol: "https",
        hostname: "img.itch.zone"
      }
    ]
  }
};

export default nextConfig;

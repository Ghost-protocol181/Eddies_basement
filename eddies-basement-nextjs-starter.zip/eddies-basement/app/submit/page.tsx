import { SubmitGameForm } from "@/components/SubmitGameForm";

export default function SubmitPage() {
  return (
    <>
      <div className="eyebrow">Community submissions</div>
      <h1 className="page-title">Suggest a game for the shelf.</h1>
      <p className="lede">
        Submit official links only. Eddie&apos;s Basement should avoid piracy, fake free trials, subscription-only traps, and sketchy download funnels.
      </p>
      <SubmitGameForm />
    </>
  );
}

import { NextResponse } from "next/server";
import { getAllGames } from "@/lib/games";

export async function GET() {
  return NextResponse.json({ games: getAllGames() });
}

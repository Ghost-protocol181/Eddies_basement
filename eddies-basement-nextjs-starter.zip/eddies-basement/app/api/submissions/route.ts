import { NextResponse } from "next/server";
import type { Submission } from "@/lib/types";

export async function POST(request: Request) {
  const body = (await request.json()) as Partial<Submission>;

  if (!body.gameName || !body.officialUrl) {
    return NextResponse.json({ error: "Game name and official URL are required." }, { status: 400 });
  }

  // MVP behavior: return a pending review object.
  // Production behavior: persist this to Supabase/Postgres with user, source, media, and review status fields.
  return NextResponse.json({
    status: "pending_review",
    submission: {
      ...body,
      createdAt: new Date().toISOString()
    }
  });
}

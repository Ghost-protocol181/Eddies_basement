import Link from "next/link";
import { GameShelfRow } from "@/components/GameShelfRow";
import { getAllGames, getFamilyGames, getFeaturedGames, getPlayNowGames } from "@/lib/games";

export default function HomePage() {
  const allGames = getAllGames();
  const featured = getFeaturedGames();
  const playNow = getPlayNowGames();
  const family = getFamilyGames();
  const party = allGames.filter((game) => game.multiplayerTypes.includes("Party")).slice(0, 12);
  const coop = allGames.filter((game) => game.multiplayerTypes.includes("Co-op")).slice(0, 12);

  return (
    <>
      <section className="hero">
        <div className="eyebrow">The visual free multiplayer finder</div>
        <h1>Pull something off the shelf.</h1>
        <p>
          Free multiplayer games are everywhere. The hard part is finding ones that are actually free, actually playable, and worth loading up with friends.
        </p>
        <div className="hero-actions">
          <Link className="button primary" href="/games">Open the Game Shelf</Link>
          <Link className="button ghost" href="/submit">Submit a Game</Link>
        </div>
        <div className="hero-stats">
          <div className="stat-card"><strong>{allGames.length}</strong><span>default visible listings</span></div>
          <div className="stat-card"><strong>{playNow.length}</strong><span>play-right-now picks</span></div>
          <div className="stat-card"><strong>0</strong><span>trial-only games shown by default</span></div>
        </div>
      </section>

      <GameShelfRow title="Featured Shelf" description="Big-cover browsing inspired by the old movie-store wall, but for free multiplayer games." games={featured} />
      <GameShelfRow title="Play Right Now" description="Browser-first picks with low friction and no download required." games={playNow} />
      <GameShelfRow title="Good With a Group" description="Party and group games that are easy to browse when everyone is standing around asking what to play." games={party} />
      <GameShelfRow title="Co-op Corner" description="Games where friends work together instead of immediately yelling at each other." games={coop} />
      <GameShelfRow title="Family Browse" description="Listings that prioritize quick setup, no download, clear player counts, and low monetization." games={family} />
    </>
  );
}

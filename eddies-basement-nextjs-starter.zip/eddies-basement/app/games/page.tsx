import { DirectoryClient } from "@/components/DirectoryClient";
import { getAllGames } from "@/lib/games";

export default function GamesPage() {
  const games = getAllGames({ includeQuestionable: true });

  return (
    <>
      <div className="eyebrow">Game Shelf</div>
      <h1 className="page-title">Browse free multiplayer games.</h1>
      <p className="lede">
        Search by graphics, genre, platform, player count, or the kind of night you&apos;re trying to have. The default view hides fake-free and subscription-required listings.
      </p>
      <DirectoryClient games={games} />
    </>
  );
}

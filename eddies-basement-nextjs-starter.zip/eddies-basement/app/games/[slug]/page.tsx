import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Badge } from "@/components/Badge";
import { GameShelfRow } from "@/components/GameShelfRow";
import { ScreenshotCarousel } from "@/components/ScreenshotCarousel";
import { TrustBadge } from "@/components/TrustBadge";
import { getAllGames, getGameBySlug, getSimilarGames } from "@/lib/games";
import { getPrimaryArtwork } from "@/lib/media";

export function generateStaticParams() {
  return getAllGames({ includeQuestionable: true }).map((game) => ({ slug: game.slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const game = getGameBySlug(slug);
  return {
    title: game ? `${game.title} | Eddie's Basement` : "Game not found | Eddie's Basement",
    description: game?.shortDescription
  };
}

export default async function GameDetailPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const game = getGameBySlug(slug);
  if (!game) notFound();

  const similar = getSimilarGames(game);
  const artwork = getPrimaryArtwork(game);
  const playerCount = game.playerCountMin === game.playerCountMax ? `${game.playerCountMin}` : `${game.playerCountMin}-${game.playerCountMax}`;

  return (
    <>
      <section className="detail-hero">
        <div className="detail-cover">
          <img src={artwork} alt={`${game.title} cover artwork`} />
        </div>
        <div className="detail-copy">
          <div className="eyebrow">Game details</div>
          <h1>{game.title}</h1>
          <p className="lede">{game.description}</p>
          <div className="card-meta">
            <TrustBadge game={game} />
            {game.eddiesPick ? <Badge tone="purple">Eddie&apos;s Pick</Badge> : null}
            <Badge tone="blue">{playerCount} players</Badge>
            <Badge tone={game.downloadRequired ? "orange" : "green"}>{game.downloadRequired ? "Download required" : "No download"}</Badge>
            <Badge tone={game.accountRequired ? "orange" : "green"}>{game.accountRequired ? "Account likely" : "No account flagged"}</Badge>
          </div>
          <div className="detail-actions">
            <a className="button primary" href={game.officialUrl} target="_blank" rel="noreferrer">Play / Visit official page</a>
            <Link className="button ghost" href="/games">Back to shelf</Link>
          </div>
        </div>
      </section>

      <section className="detail-layout">
        <div className="info-panel">
          <h2 style={{ marginTop: 0 }}>Shelf preview</h2>
          <p className="muted">
            This page supports approved cover art, hero art, screenshots, GIF-style previews, and video previews. Prototype artwork should be replaced with official or permission-safe media before launch.
          </p>
          <ScreenshotCarousel urls={game.screenshotUrls} title={game.title} />
        </div>
        <aside className="info-panel">
          <h2 style={{ marginTop: 0 }}>Free status</h2>
          <div className="spec-grid">
            <div className="spec"><span>Free status</span><strong>{game.freeStatus.replaceAll("_", " ")}</strong></div>
            <div className="spec"><span>Monetization</span><strong>{game.monetizationLevel}</strong></div>
            <div className="spec"><span>Trust score</span><strong>{game.trustScore}/100</strong></div>
            <div className="spec"><span>Last checked</span><strong>{new Date(game.lastCheckedAt).toLocaleDateString()}</strong></div>
            <div className="spec"><span>Platforms</span><strong>{game.platforms.join(", ")}</strong></div>
            <div className="spec"><span>Modes</span><strong>{game.multiplayerTypes.join(", ")}</strong></div>
          </div>
          <p className="small" style={{ marginTop: 14 }}>
            Source: {game.sourceName}. Real production listings should be verified against official pages and source terms.
          </p>
        </aside>
      </section>

      <GameShelfRow title="Similar games" description="More games with overlapping platforms, genres, or multiplayer modes." games={similar} />
    </>
  );
}

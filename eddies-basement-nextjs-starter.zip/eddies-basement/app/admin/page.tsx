import { AdminReviewClient } from "@/components/AdminReviewClient";

export default function AdminPage() {
  return (
    <>
      <div className="eyebrow">Admin prototype</div>
      <h1 className="page-title">Review the basement.</h1>
      <p className="lede">
        This mock shows the shape of the future admin workflow: approve listings, verify free status, review media, and flag questionable monetization.
      </p>
      <AdminReviewClient />
    </>
  );
}

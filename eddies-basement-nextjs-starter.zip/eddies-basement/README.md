# Eddie's Basement

A visual free multiplayer game finder inspired by an old movie-store shelf, LAN party basement, and arcade wall.

This starter app is a polished Next.js prototype with:

- A dark, cozy game-shelf UI
- Visual cover cards
- Hover/tap previews
- Search and filters
- Game detail pages
- Submission form
- Mock admin review page
- Seed data
- Media fields for cover art, hero art, screenshots, GIF-style previews, and video previews
- Source adapter structure for future ingestion
- Guardrails to hide trial-only and subscription-required listings by default

## Important product note

Do **not** position this as an app that aggressively scans the entire internet in real time. A production version should be a responsible discovery engine that combines curated sources, official APIs, approved feeds, community submissions, and admin review.

Future source adapters should respect:

- API terms
- robots.txt
- rate limits
- copyright
- media usage rights
- store/platform terms

The seed listings are prototype placeholders. Replace them with verified official listings before public launch.

## Run locally

```bash
npm install
npm run dev
```

Open `http://localhost:3000`.

## Suggested Codex next steps

Paste this into Codex after opening the folder:

```text
Continue building Eddie's Basement. Keep the current Next.js App Router + TypeScript structure. Improve the product beyond a demo by adding persistence, real admin auth, Supabase tables, real source adapters, stronger media approval workflow, and production-ready verification logic. Do not add aggressive scraping. Keep the visual Blockbuster-style Game Shelf as the default browsing experience. Preserve performance: lazy-load images/videos, avoid loading all GIFs/videos at page load, respect prefers-reduced-motion, and keep mobile browsing smooth.
```

## Project structure

```text
app/
  page.tsx
  games/page.tsx
  games/[slug]/page.tsx
  submit/page.tsx
  admin/page.tsx
  api/games/route.ts
  api/submissions/route.ts
components/
  AdminReviewClient.tsx
  Badge.tsx
  DirectoryClient.tsx
  FilterBar.tsx
  GameCoverCard.tsx
  GameGrid.tsx
  GameShelfRow.tsx
  MediaBadge.tsx
  MediaPreviewCard.tsx
  PreviewVideo.tsx
  ScreenshotCarousel.tsx
  SearchBar.tsx
  SiteShell.tsx
  SubmitGameForm.tsx
  TrustBadge.tsx
  ViewToggle.tsx
hooks/
  useInView.ts
  usePrefersReducedMotion.ts
lib/
  filters.ts
  games.ts
  media.ts
  seed.ts
  types.ts
  sources/
public/
  covers/
  previews/
  screens/
```

## How previews work

Each game supports:

```ts
coverImageUrl?: string;
heroImageUrl?: string;
thumbnailUrl?: string;
previewGifUrl?: string;
previewVideoUrl?: string;
previewVideoPosterUrl?: string;
screenshotUrls?: string[];
mediaAttribution?: string;
mediaSourceUrl?: string;
mediaStatus: "missing" | "pending_review" | "approved" | "needs_replacement";
```

The card shows cover art first. On hover/focus/tap it attempts to show:

1. Preview video if available
2. GIF/animated image if available
3. Screenshot fallback
4. Static cover fallback

## Production database idea

Start with these tables:

- games
- game_media
- submissions
- source_runs
- source_findings
- admin_reviews
- users
- favorites

## Free-status rules

Default results hide games unless:

```ts
isFreeToPlay === true
requiresSubscription === false
freeStatus !== "free_trial_only"
freeStatus !== "subscription_required"
```

Monetization should be surfaced clearly:

- `none`: green / safest
- `light`: yellow / optional purchases
- `moderate`: orange / playable but watch it
- `heavy`: hidden by default or clearly warned
- `unknown`: needs review

## Media rights

Do not hotlink or reuse official game art without checking usage terms. Production should cache approved thumbnails/previews in a storage bucket/CDN when allowed. Admins should be able to replace media and set `mediaStatus`.
